# WordPress MySQL database migration
#
# Generated: Wednesday 25. March 2020 19:31 UTC
# Hostname: localhost
# Database: `nousotdb`
# URL: //localhost/nousot
# Path: /Library/WebServer/Documents/nousot
# Tables: wp_commentmeta, wp_comments, wp_hidemysiteSecure, wp_links, wp_options, wp_postmeta, wp_posts, wp_swp_cf, wp_swp_index, wp_swp_log, wp_swp_tax, wp_swp_terms, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-02-07 01:32:13', '2020-02-07 01:32:13', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_hidemysiteSecure`
#

DROP TABLE IF EXISTS `wp_hidemysiteSecure`;


#
# Table structure of table `wp_hidemysiteSecure`
#

CREATE TABLE `wp_hidemysiteSecure` (
  `id` mediumint(12) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `time` varchar(20) NOT NULL,
  `repeated_fails` varchar(20) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_hidemysiteSecure`
#

#
# End of data contents of table `wp_hidemysiteSecure`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=472 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/nousot', 'yes'),
(2, 'home', 'http://localhost/nousot', 'yes'),
(3, 'blogname', 'Website', 'yes'),
(4, 'blogdescription', 'Products + Services', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'erica@ericadreisbach.com', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:94:{s:34:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml$";s:40:"index.php?xml_sitemap=params=$matches[2]";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml\\.gz$";s:49:"index.php?xml_sitemap=params=$matches[2];zip=true";s:35:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html$";s:50:"index.php?xml_sitemap=params=$matches[2];html=true";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html.gz$";s:59:"index.php?xml_sitemap=params=$matches[2];html=true;zip=true";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:36:"google-sitemap-generator/sitemap.php";i:2;s:37:"gutenberg-blocks/gutenberg-blocks.php";i:3;s:22:"hide-my-site/index.php";i:4;s:63:"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php";i:5;s:21:"searchwp/searchwp.php";i:6;s:27:"svg-support/svg-support.php";i:7;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'html5blank-stable', 'yes'),
(41, 'stylesheet', 'nousot-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '45805', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:4:"text";s:44:"Privacy Policy\r\n\r\nCopyright [copyright-year]";s:6:"filter";b:1;s:6:"visual";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Chicago', 'yes'),
(83, 'page_for_posts', '26', 'yes'),
(84, 'page_on_front', '2', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1596591133', 'yes'),
(94, 'initial_db_version', '45805', 'yes'),
(95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:12:"footer-menus";a:2:{i:0;s:13:"media_image-2";i:1;s:10:"nav_menu-2";}s:9:"copyright";a:1:{i:0;s:6:"text-2";}s:13:"array_version";i:3;}', 'yes'),
(103, 'cron', 'a:6:{i:1585164734;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1585186334;a:4:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1585186394;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1585238520;a:1:{s:15:"swp_maintenance";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1585242120;a:1:{s:13:"sm_ping_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(104, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_image', 'a:2:{i:2;a:15:{s:4:"size";s:6:"medium";s:5:"width";i:300;s:6:"height";i:300;s:7:"caption";s:0:"";s:3:"alt";s:0:"";s:9:"link_type";s:6:"custom";s:8:"link_url";s:24:"http://localhost/nousot/";s:13:"image_classes";s:0:"";s:12:"link_classes";s:0:"";s:8:"link_rel";s:0:"";s:17:"link_target_blank";b:0;s:11:"image_title";s:0:"";s:13:"attachment_id";i:11;s:3:"url";s:59:"http://localhost/nousot/wp-content/uploads/2020/03/logo.svg";s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:2:{i:2;a:2:{s:5:"title";s:25:"Follow Us on Social Media";s:8:"nav_menu";i:2;}s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'recovery_keys', 'a:0:{}', 'yes'),
(121, 'theme_mods_twentytwenty', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1585075679;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:1:{i:0;s:6:"text-2";}s:9:"sidebar-2";a:2:{i:0;s:13:"media_image-2";i:1;s:10:"nav_menu-2";}}}s:18:"nav_menu_locations";a:2:{s:7:"primary";i:3;s:6:"social";i:2;}}', 'yes'),
(139, 'can_compress_scripts', '1', 'no'),
(160, '_wp_suggested_policy_text_has_changed', 'not-changed', 'yes'),
(174, 'recently_activated', 'a:0:{}', 'yes'),
(182, 'current_theme', 'Dark Black LLC', 'yes'),
(183, 'theme_mods_darkblack-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1584890982;s:4:"data";a:5:{s:19:"wp_inactive_widgets";a:0:{}s:12:"footer-menus";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}s:9:"copyright";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:13:"widget-area-1";a:0:{}s:13:"widget-area-2";a:0:{}}}}', 'yes'),
(184, 'theme_switched', '', 'yes'),
(187, 'theme_mods_nousot-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:5:{s:11:"social-menu";i:2;s:9:"main-menu";i:3;s:13:"footer-menu-1";i:3;s:13:"footer-menu-2";i:0;s:13:"footer-menu-3";i:0;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1585072532;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:12:"footer-menus";a:2:{i:0;s:13:"media_image-2";i:1;s:10:"nav_menu-2";}s:9:"copyright";a:1:{i:0;s:6:"text-2";}}}}', 'yes'),
(189, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(190, 'bodhi_svgs_plugin_version', '2.3.17', 'yes'),
(191, 'sm_rewrite_done', '$Id: sitemap-loader.php 937300 2014-06-23 18:04:11Z arnee $', 'yes'),
(193, 'searchwp_indexer', 'a:3:{s:19:"initial_index_built";b:1;s:5:"stats";a:5:{s:13:"last_activity";i:1585063719;s:5:"total";i:9;s:9:"remaining";i:0;s:4:"done";i:9;s:10:"in_process";b:0;}s:7:"running";b:0;}', 'no'),
(194, 'searchwp_settings', 'a:18:{s:7:"engines";a:1:{s:7:"default";a:3:{s:4:"post";a:3:{s:7:"enabled";b:1;s:7:"weights";a:6:{s:3:"tax";a:3:{s:8:"category";i:0;s:8:"post_tag";i:0;s:11:"post_format";i:0;}s:5:"title";i:80;s:7:"content";i:5;s:7:"excerpt";i:40;s:4:"slug";i:60;s:7:"comment";i:1;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}s:4:"page";a:3:{s:7:"enabled";b:1;s:7:"weights";a:5:{s:3:"tax";a:0:{}s:5:"title";i:80;s:7:"content";i:5;s:4:"slug";i:60;s:7:"comment";i:1;}s:7:"options";a:4:{s:7:"exclude";s:6:"40, 49";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}s:10:"attachment";a:3:{s:7:"enabled";b:0;s:7:"weights";a:6:{s:3:"tax";a:0:{}s:5:"title";i:80;s:7:"content";i:5;s:7:"excerpt";i:40;s:4:"slug";i:60;s:7:"comment";i:0;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}}}s:9:"activated";b:1;s:9:"dismissed";a:2:{s:16:"filter_conflicts";a:0:{}s:4:"nags";a:0:{}}s:7:"notices";a:0:{}s:20:"valid_db_environment";b:1;s:15:"ignored_queries";b:0;s:6:"remote";b:0;s:11:"remote_meta";b:0;s:14:"nuke_on_delete";b:0;s:16:"initial_settings";b:1;s:19:"initial_index_built";b:1;s:5:"stats";a:5:{s:13:"last_activity";i:1585063231;s:5:"total";i:10;s:9:"remaining";i:0;s:4:"done";i:10;s:10:"in_process";b:0;}s:7:"running";b:0;s:7:"utf8mb4";s:1:"1";s:8:"endpoint";s:0:"";s:14:"legacy_engines";b:0;s:11:"index_dirty";b:0;s:10:"basic_auth";s:2:"no";}', 'yes'),
(195, 'searchwp_settings_backup', 'a:0:{}', 'no'),
(196, 'searchwp_purge_queue', 'a:0:{}', 'no'),
(197, 'searchwp_progress', '100.00', 'no'),
(198, 'searchwp_utf8mb4', '1', 'no'),
(199, 'searchwp_version', '3.1.11', 'no'),
(202, 'acf_version', '5.8.8', 'yes'),
(208, 'searchwp_busy', '', 'no'),
(209, 'searchwp_delta_attempts', '0', 'no'),
(210, 'searchwp_processing_purge_queue', '0', 'no'),
(211, 'searchwp_license_status', 'valid', 'yes'),
(212, 'searchwp_license_expiration', '1591160399', 'yes'),
(213, 'searchwp_license_key', '72e96567734950bc1b1e1037b320aaac', 'yes'),
(220, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5T0RFeE1EUjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMkxUQTFMVEEzSURFNU9qRXpPak15IjtzOjM6InVybCI7czoyMzoiaHR0cDovL2xvY2FsaG9zdC9ub3Vzb3QiO30=', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(224, 'edd_sl_64b2b3dfe202f6b64b85c8f5a41dcce7', 'a:2:{s:7:"timeout";i:1585092018;s:5:"value";s:44210:"{"new_version":"3.1.11","stable_version":"3.1.11","name":"SearchWP","slug":"searchwp","url":"https:\\/\\/searchwp.com\\/downloads\\/searchwp\\/?changelog=1","last_updated":"2020-03-05 07:38:33","homepage":"https:\\/\\/searchwp.com\\/downloads\\/searchwp\\/","package":"https:\\/\\/searchwp.com\\/edd-sl\\/package_download\\/MTU4NTE5NjQxODo3MmU5NjU2NzczNDk1MGJjMWIxZTEwMzdiMzIwYWFhYzo4OmQ3ODY1ODZiODFjMDI2MTU1NjQ5NjYzYWVhM2IxOGVkOmh0dHBALy9sb2NhbGhvc3Qvbm91c290OjA=","download_link":"https:\\/\\/searchwp.com\\/edd-sl\\/package_download\\/MTU4NTE5NjQxODo3MmU5NjU2NzczNDk1MGJjMWIxZTEwMzdiMzIwYWFhYzo4OmQ3ODY1ODZiODFjMDI2MTU1NjQ5NjYzYWVhM2IxOGVkOmh0dHBALy9sb2NhbGhvc3Qvbm91c290OjA=","sections":{"description":"","changelog":"<p>3.1.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with synonym partial matching not working as expected in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with supported post type attributes not appearing in all cases<\\/li>\\n<li><strong>[Change]<\\/strong> Template conflict detection is now opt-in<\\/li>\\n<li><strong>[Update]<\\/strong> Updated dependencies<\\/li>\\n<\\/ul>\\n<p>3.1.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Logic issue with one of the query limiters in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> searchwp_query_strict_limiters filter allowing you to <em>opt out<\\/em> of some search query limiters<\\/li>\\n<li><strong>[Change]<\\/strong> Some private properties\\/methods have been made public<\\/li>\\n<\\/ul>\\n<p>3.1.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with finding partial matches in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP 7.4 compatibility<\\/li>\\n<li><strong>[Update]<\\/strong> Adds class reference to some hooks<\\/li>\\n<li><strong>[Update]<\\/strong> Dependencies<\\/li>\\n<\\/ul>\\n<p>3.1.6<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Default partial match minimum length updated to 3<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of quoted searches when highlighting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Integration with WordPress 5.3<\\/li>\\n<li><strong>[Improvement]<\\/strong> Exact matches given more weight when finding partial matches<\\/li>\\n<li><strong>[Fix]<\\/strong> SWP_Query quoted search handling in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Performance when considering document processing<\\/li>\\n<li><strong>[Fix]<\\/strong> Partial matches resource usage<\\/li>\\n<\\/ul>\\n<p>3.1.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Regression introduced when debugging is enabled and FS_METHOD = ftpext is imposed<\\/li>\\n<li><strong>[Fix]<\\/strong> Custom built admin searches not working as expected in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Search query performance<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of AND logic when considering partial matches and synonyms<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improve performance of partial match handling<\\/li>\\n<li><strong>[Improvement]<\\/strong> Prevention of redundant queries in some cases<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_th_excerpt_consider_comments to consider Comments when generating global excerpts if no highlight is found<\\/li>\\n<\\/ul>\\n<p>3.1.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with tokenizing during searches in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes a regression in synonym processing introduced in 3.1<\\/li>\\n<li><strong>[Improvement]<\\/strong> Performance improvement when performing searches<\\/li>\\n<\\/ul>\\n<p>3.1.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Indexer performance regression introduced in 3.1<\\/li>\\n<li><strong>[Fix]<\\/strong> Inaccurate notice displayed when searching in the admin in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> JavaScript error when adding Custom Fields to engines<\\/li>\\n<\\/ul>\\n<p>3.1<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Partial term matching now requires PHP 5.4+<\\/li>\\n<li><strong>[Change]<\\/strong> Synonym handling has been improved, for full explanation see <a href=\\"https:\\/\\/searchwp.com\\/?p=193232\\">https:\\/\\/searchwp.com\\/?p=193232<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Support (with caveats) for quoted\\/phrase\\/sentence searches, for more information see <a href=\\"https:\\/\\/searchwp.com\\/?p=190759\\">https:\\/\\/searchwp.com\\/?p=190759<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Automatic \\"Did you mean\\" handling for misspelled searches, for more information see <a href=\\"https:\\/\\/searchwp.com\\/?p=190545\\">https:\\/\\/searchwp.com\\/?p=190545<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Adds core support for keyword stemming for these language codes: EN, DA, NL, FR, DE, IT, NB, NN, PT, RO, RU, ES, SV (if you are using an Extension you can remove it)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_collate_override to override table COLLATE<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_th_minimum_word_length to control highlighter minimum word length<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_persist_extra_metadata to control whether Extra Metadata is persisted (e.g. to support quoted searches for that data)<\\/li>\\n<li><strong>[New]<\\/strong> Detection for background indexer communication failure in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Global excerpts now implement WordPress\' excerpt_more output where applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Partial match highlighting is more accurate<\\/li>\\n<li><strong>[Improvement]<\\/strong> JavaScript bundlers have been reconfigured and optimized<\\/li>\\n<li><strong>[Fix]<\\/strong> Account for AND logic refinement being too aggressive in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Trigger index when scheduled posts are published<\\/li>\\n<li><strong>[Fix]<\\/strong> Delta updates when editing via Quick Edit<\\/li>\\n<li><strong>[Fix]<\\/strong> Better checks against index when evaluating partial matches<\\/li>\\n<li><strong>[Fix]<\\/strong> SWP_Query results are no longer incorrectly overridden with subsequent calls to SWP_Query-&gt;get_posts()<\\/li>\\n<li><strong>[Fix]<\\/strong> Highlighter partial match setting now defaults to core partial match setting<\\/li>\\n<li><strong>[Fix]<\\/strong> Warning when processing purge queue in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Parent weight transfer for Media is no longer enabled by default<\\/li>\\n<li><strong>[Fix]<\\/strong> Global highlight functions are now initialized in a more accessible way<\\/li>\\n<li><strong>[Fix]<\\/strong> z-index problem when adding a Post Type to an engine<\\/li>\\n<li><strong>[Fix]<\\/strong> More consistent handling of internal metadata types<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent inapplicable post types from being considered for search when in the WordPress Dashboard<\\/li>\\n<li><strong>[Fix]<\\/strong> Take exclusive regex matches into consideration when tokenizing<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<\\/ul>\\n<p>3.0.7<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Handling of highlighter logic<\\/li>\\n<li><strong>[Improvement]<\\/strong> Highlighter excerpt generation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug environment checks\\/messaging<\\/li>\\n<li><strong>[Improvement]<\\/strong> Provide feedback when synonyms are influenced by other tokenizer rules<\\/li>\\n<li><strong>[Improvement]<\\/strong> Index statistics calculation<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with multiple-word source terms for synonyms not being processed correctly in all cases<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_mods_wrap_core_weights to support additional weight customizations<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>3.0.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> When enabling Admin search hijacking you must now choose an engine to use for Admin searches<\\/li>\\n<li><strong>[Change]<\\/strong> Regex pattern matches are processed by min word length and stopword removal rules<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_apply_rules_to_whitelisted_terms controls whether rules (min word length, stopword removal) applies to whitelisted terms<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with partial matching when multiple searches are run for a single request<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent parent attribution when searching in the Admin (would result in false negatives)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Partial match processing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of delta updates to reduce resource usage<\\/li>\\n<li><strong>[Improvement]<\\/strong> System Information is now more comprehensive<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<\\/ul>\\n<p>3.0.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Pasting of comma separated Stopwords will create individual Stopwords from the list<\\/li>\\n<li><strong>[Fix]<\\/strong> Conditional disabling of partial matches per engine by using provided filter<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent missing exact matches when finding partial matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Post types that are excluded from search during registration are now listed out<\\/li>\\n<li><strong>[Improvement]<\\/strong> When Metrics is installed the engine configuration Search Statistics link is correct<\\/li>\\n<li><strong>[Change]<\\/strong> Enabling partial matches no longer gives exact matches full priority, short circuiting on exact matches is now opt in via filter<\\/li>\\n<li><strong>[Change]<\\/strong> Third party dependencies have been reorganized to reduce file path which should help to avoid issues on certain Windows servers<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<li><strong>[Update]<\\/strong> PHP version compatibility<\\/li>\\n<li><strong>[Update]<\\/strong> Dependency update which brings additional PHP compatibility<\\/li>\\n<li><strong>[Security]<\\/strong> TCPDF security update (which as evaluated could NOT have been exploited)<\\/li>\\n<\\/ul>\\n<p>3.0.4<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Handling of multiple word highlighting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better restriction during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with Advanced Custom Fields repeater detection<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of cached data<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent unwanted indexer activity when using searchwp_indexed_post_types<\\/li>\\n<li><strong>[Change]<\\/strong> Removal of ACF field references is now opt-in<\\/li>\\n<li><strong>[Change]<\\/strong> searchwp_lenient_accents now applies during searches as well<\\/li>\\n<li><strong>[New]<\\/strong> Filter searchwp_lenient_accents_on_search to allow refined control over leinient accent treatment<\\/li>\\n<\\/ul>\\n<p>3.0.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with checking for unused meta keys when configuring search engines<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes a potential issue with searchwp_short_circuit being incorrectly overridden<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with synonyms not working as expected<\\/li>\\n<\\/ul>\\n<p>3.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue that may prevent Custom Fields from appearing in engine configuration<\\/li>\\n<\\/ul>\\n<p>3.0<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Advanced Settings screen rebuilt and optimized<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_legacy_advanced_settings filter controls whether the legacy Advanced Settings screen is used<\\/li>\\n<li><strong>[New]<\\/strong> Integrated stopword management on the Advanced Settings screen<\\/li>\\n<li><strong>[New]<\\/strong> Default stopwords for the following locales: CS, DA, DE, EN, ES, FI, GA, IT, NL, PL, PT, RO, RU, SV, TR<\\/li>\\n<li><strong>[New]<\\/strong> Suggested stopwords based on existing site content<\\/li>\\n<li><strong>[New]<\\/strong> Integrated Term Synonyms and improved management UI (extension is now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Integrated Term Highlight (extension is now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Integrated LIKE Terms and Fuzzy Matches (extensions are now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Adds setting to parse Shortcodes during indexing (e.g. UI for searchwp_do_shortcodes)<\\/li>\\n<li><strong>[New]<\\/strong> SWP_Query now has the following methods: have_posts, rewind_posts, the_post, next_post allowing for a more traditional Loop<\\/li>\\n<li><strong>[New]<\\/strong> Custom Fields dropdown now supports meta groups<\\/li>\\n<li><strong>[New]<\\/strong> Automatic UI for \\"repeatable\\" field groups in Advanced Custom Fields<\\/li>\\n<li><strong>[New]<\\/strong> Statistics screen rebuilt and optimized<\\/li>\\n<li><strong>[New]<\\/strong> Management of ignored searches is now built in to the Stats screen<\\/li>\\n<li><strong>[New]<\\/strong> Resetting of statistics is now built in to the Stats screen<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_statistics_popular_days_{$days} filter allows overriding of popular search queries<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_legacy_stats filter controls whether the legacy Advanced Settings screen is used<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_results_found_posts filter allows modification of SearchWP\'s found posts<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_results_max_num_pages filter allows modification of SearchWP\'s maximum number of pages<\\/li>\\n<li><strong>[New]<\\/strong> Support for programmatic license management. See SearchWP_License class<\\/li>\\n<li><strong>[New]<\\/strong> Adds (dismiss-able) notice during admin searches when admin searches are not hijacked by SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> Adds support for WordPress\' block editor during indexing (blocks will be parsed prior to indexing)<\\/li>\\n<li><strong>[Fix]<\\/strong> Adds support for results limiting when parent attribution is enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of emoji during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent pattern whitelist matches from being counted twice<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent data mutation when creating multiple supplemental engines at once<\\/li>\\n<li><strong>[Change]<\\/strong> Indexing emoji is now opt-in using the searchwp_index_emoji filter<\\/li>\\n<\\/ul>\\n<p>2.9.17<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of post status and comment triggers of delta updates, reducing significant overhead in some cases<\\/li>\\n<\\/ul>\\n<p>2.9.16<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue that prevented proper respect of searchwp_background_deltas<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with debug log permissions in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where Custom Field keys were not accurately retrieved in older versions of WordPress<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes settings screen JavaScript error in IE11<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue preventing the application of searchwp_search_query_order<\\/li>\\n<li><strong>[Improvement]<\\/strong> Notes the requirement that the index must be rebuilt after ticking checkbox to remove minimum character count<\\/li>\\n<li><strong>[New]<\\/strong> Adds post_status parameter to SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Adds order parameter to SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Adds limited orderby parameter to SWP_Query<\\/li>\\n<\\/ul>\\n<p>2.9.15<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where in some cases delta update requests were not processed correctly<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> The debug log generation process has been improved and the debug log more streamlined\\/readable<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_debug_detailed to control whether detailed items are logged when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.9.14<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes false positive error message relating to HTTP Basic Authentication<\\/li>\\n<li><strong>[Fix]<\\/strong> Resolves an issue preventing translations from loading as expected<\\/li>\\n<li><strong>[Change]<\\/strong> Algorithm SQL has been updated to be more specific when considering Custom Fields and Taxonomies<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_dashboard_widget_transient_ttl that allows for customization of cache duration of Dashboard Widget data<\\/li>\\n<\\/ul>\\n<p>2.9.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Prevent redundant statistics logging on paginated results when using SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of taxonomy terms with special characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning and PHP Notice in certain cases<\\/li>\\n<\\/ul>\\n<p>2.9.12<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Index better optimized when limiting to Media mime type<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic is more restrictive when applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of license key when provided via constant or filter<\\/li>\\n<li><strong>[Update]<\\/strong> Updates translation source<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes inaccurate indexer progress in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes handling of All Documents mime type Media limiter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning<\\/li>\\n<\\/ul>\\n<p>2.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong>\\u00a0Additional index optimization when delta updates are applied via new filter searchwp_aggressive_delta_update<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug output cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Implements omitted filter argument<\\/li>\\n<\\/ul>\\n<p>2.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves an issue where AND logic wasn\'t strict enough in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Relocated searchwp_indexer_pre action trigger to restore expected behavior<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additinal refinements to delta update queue processing to prevent excessive server resource usage in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Adds edit icon to supplemental engine name to communicate it is editable<\\/li>\\n<li><strong>[Change]<\\/strong> License key is no longer displayed in license key field if populated via constant or hook<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_engine_use_taxonomy_name that controls displaying name or label of Taxonomies in enging settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_and_fields_{$post_type} allowing for AND field customization per post type<\\/li>\\n<\\/ul>\\n<p>2.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where post type Limit rules were too aggressive in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined index delta update routine to reduce potentially unnecessary triggers<\\/li>\\n<\\/ul>\\n<p>2.9.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves issue of inaccurate results count when parent attribution is in effect<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better processing of engine Rules during indexing<\\/li>\\n<\\/ul>\\n<p>2.9.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed link in admin notice<\\/li>\\n<\\/ul>\\n<p>2.9.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue causing newly regiestered taxonomies to be unavailable in settings UI<\\/li>\\n<li><strong>[Fix]<\\/strong> Messaging for index being out of date is now more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Paged searches are no longer redundantly logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default regex patterns by making them more strict<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing libraries<\\/li>\\n<\\/ul>\\n<p>2.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any Custom Field\' did not work as expected in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomies added since the last engine save may not be available<\\/li>\\n<li><strong>[Improvement]<\\/strong> Actual weight multiplier is displayed in tooltip<\\/li>\\n<\\/ul>\\n<p>2.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS bug causing multiselect overlapping when configuring multiple post types<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue preventing searches of hierarchical post types in the admin<\\/li>\\n<\\/ul>\\n<p>2.9.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a searchwp_and_logic_only regression introduced in 2.9<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial default engine model<\\/li>\\n<\\/ul>\\n<p>2.9.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with some custom ORDER BY statements<\\/li>\\n<\\/ul>\\n<p>2.9.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with sql_mode=only_full_group_by support (added in 2.9)<\\/li>\\n<li><strong>[Fix]<\\/strong> Avoid error when parsing PDFs without mbstring<\\/li>\\n<\\/ul>\\n<p>2.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Redesigned engine configuration interface!<\\/li>\\n<li><strong>[New]<\\/strong> Index is now further optimized as per engine settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_max to customize a maximum weight<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_legacy_settings_ui to use legacy settings UI<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_apply_engines_rules to control whether engine rules are considered during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_additional_meta_exclusions to control whether default additional Custom Fields are excluded from indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_supports_label_{post_type}_{support} to customize the label used for a post type native attribute<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional debug statements output when enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better formatting of HTML comment debug output<\\/li>\\n<li><strong>[Fix]<\\/strong> Less aggressive handling of pre_get_posts during searching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix an issue with sql_mode=only_full_group_by (default in MySQL 5.7)<\\/li>\\n<\\/ul>\\n<p>For older versions please see <a href=\\"https:\\/\\/searchwp.com\\/docs\\/changelog-archive\\/\\" target=\\"_blank\\" rel=\\"noopener\\">the changelog archive<\\/a><\\/p>\\n"},"banners":{"high":"","low":""},"icons":[],"requires_php":"5.6.0","description":[""],"changelog":["<p>3.1.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with synonym partial matching not working as expected in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with supported post type attributes not appearing in all cases<\\/li>\\n<li><strong>[Change]<\\/strong> Template conflict detection is now opt-in<\\/li>\\n<li><strong>[Update]<\\/strong> Updated dependencies<\\/li>\\n<\\/ul>\\n<p>3.1.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Logic issue with one of the query limiters in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> searchwp_query_strict_limiters filter allowing you to <em>opt out<\\/em> of some search query limiters<\\/li>\\n<li><strong>[Change]<\\/strong> Some private properties\\/methods have been made public<\\/li>\\n<\\/ul>\\n<p>3.1.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with finding partial matches in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP 7.4 compatibility<\\/li>\\n<li><strong>[Update]<\\/strong> Adds class reference to some hooks<\\/li>\\n<li><strong>[Update]<\\/strong> Dependencies<\\/li>\\n<\\/ul>\\n<p>3.1.6<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Default partial match minimum length updated to 3<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of quoted searches when highlighting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Integration with WordPress 5.3<\\/li>\\n<li><strong>[Improvement]<\\/strong> Exact matches given more weight when finding partial matches<\\/li>\\n<li><strong>[Fix]<\\/strong> SWP_Query quoted search handling in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Performance when considering document processing<\\/li>\\n<li><strong>[Fix]<\\/strong> Partial matches resource usage<\\/li>\\n<\\/ul>\\n<p>3.1.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Regression introduced when debugging is enabled and FS_METHOD = ftpext is imposed<\\/li>\\n<li><strong>[Fix]<\\/strong> Custom built admin searches not working as expected in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Search query performance<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of AND logic when considering partial matches and synonyms<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improve performance of partial match handling<\\/li>\\n<li><strong>[Improvement]<\\/strong> Prevention of redundant queries in some cases<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_th_excerpt_consider_comments to consider Comments when generating global excerpts if no highlight is found<\\/li>\\n<\\/ul>\\n<p>3.1.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Issue with tokenizing during searches in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes a regression in synonym processing introduced in 3.1<\\/li>\\n<li><strong>[Improvement]<\\/strong> Performance improvement when performing searches<\\/li>\\n<\\/ul>\\n<p>3.1.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Indexer performance regression introduced in 3.1<\\/li>\\n<li><strong>[Fix]<\\/strong> Inaccurate notice displayed when searching in the admin in some cases<\\/li>\\n<\\/ul>\\n<p>3.1.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> JavaScript error when adding Custom Fields to engines<\\/li>\\n<\\/ul>\\n<p>3.1<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Partial term matching now requires PHP 5.4+<\\/li>\\n<li><strong>[Change]<\\/strong> Synonym handling has been improved, for full explanation see <a href=\\"https:\\/\\/searchwp.com\\/?p=193232\\">https:\\/\\/searchwp.com\\/?p=193232<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Support (with caveats) for quoted\\/phrase\\/sentence searches, for more information see <a href=\\"https:\\/\\/searchwp.com\\/?p=190759\\">https:\\/\\/searchwp.com\\/?p=190759<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Automatic \\"Did you mean\\" handling for misspelled searches, for more information see <a href=\\"https:\\/\\/searchwp.com\\/?p=190545\\">https:\\/\\/searchwp.com\\/?p=190545<\\/a><\\/li>\\n<li><strong>[New]<\\/strong> Adds core support for keyword stemming for these language codes: EN, DA, NL, FR, DE, IT, NB, NN, PT, RO, RU, ES, SV (if you are using an Extension you can remove it)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_collate_override to override table COLLATE<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_th_minimum_word_length to control highlighter minimum word length<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_persist_extra_metadata to control whether Extra Metadata is persisted (e.g. to support quoted searches for that data)<\\/li>\\n<li><strong>[New]<\\/strong> Detection for background indexer communication failure in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Global excerpts now implement WordPress\' excerpt_more output where applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Partial match highlighting is more accurate<\\/li>\\n<li><strong>[Improvement]<\\/strong> JavaScript bundlers have been reconfigured and optimized<\\/li>\\n<li><strong>[Fix]<\\/strong> Account for AND logic refinement being too aggressive in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Trigger index when scheduled posts are published<\\/li>\\n<li><strong>[Fix]<\\/strong> Delta updates when editing via Quick Edit<\\/li>\\n<li><strong>[Fix]<\\/strong> Better checks against index when evaluating partial matches<\\/li>\\n<li><strong>[Fix]<\\/strong> SWP_Query results are no longer incorrectly overridden with subsequent calls to SWP_Query-&gt;get_posts()<\\/li>\\n<li><strong>[Fix]<\\/strong> Highlighter partial match setting now defaults to core partial match setting<\\/li>\\n<li><strong>[Fix]<\\/strong> Warning when processing purge queue in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Parent weight transfer for Media is no longer enabled by default<\\/li>\\n<li><strong>[Fix]<\\/strong> Global highlight functions are now initialized in a more accessible way<\\/li>\\n<li><strong>[Fix]<\\/strong> z-index problem when adding a Post Type to an engine<\\/li>\\n<li><strong>[Fix]<\\/strong> More consistent handling of internal metadata types<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent inapplicable post types from being considered for search when in the WordPress Dashboard<\\/li>\\n<li><strong>[Fix]<\\/strong> Take exclusive regex matches into consideration when tokenizing<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<\\/ul>\\n<p>3.0.7<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Handling of highlighter logic<\\/li>\\n<li><strong>[Improvement]<\\/strong> Highlighter excerpt generation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug environment checks\\/messaging<\\/li>\\n<li><strong>[Improvement]<\\/strong> Provide feedback when synonyms are influenced by other tokenizer rules<\\/li>\\n<li><strong>[Improvement]<\\/strong> Index statistics calculation<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with multiple-word source terms for synonyms not being processed correctly in all cases<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_mods_wrap_core_weights to support additional weight customizations<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>3.0.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> When enabling Admin search hijacking you must now choose an engine to use for Admin searches<\\/li>\\n<li><strong>[Change]<\\/strong> Regex pattern matches are processed by min word length and stopword removal rules<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_apply_rules_to_whitelisted_terms controls whether rules (min word length, stopword removal) applies to whitelisted terms<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with partial matching when multiple searches are run for a single request<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent parent attribution when searching in the Admin (would result in false negatives)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Partial match processing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Handling of delta updates to reduce resource usage<\\/li>\\n<li><strong>[Improvement]<\\/strong> System Information is now more comprehensive<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<\\/ul>\\n<p>3.0.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Pasting of comma separated Stopwords will create individual Stopwords from the list<\\/li>\\n<li><strong>[Fix]<\\/strong> Conditional disabling of partial matches per engine by using provided filter<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent missing exact matches when finding partial matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Post types that are excluded from search during registration are now listed out<\\/li>\\n<li><strong>[Improvement]<\\/strong> When Metrics is installed the engine configuration Search Statistics link is correct<\\/li>\\n<li><strong>[Change]<\\/strong> Enabling partial matches no longer gives exact matches full priority, short circuiting on exact matches is now opt in via filter<\\/li>\\n<li><strong>[Change]<\\/strong> Third party dependencies have been reorganized to reduce file path which should help to avoid issues on certain Windows servers<\\/li>\\n<li><strong>[Update]<\\/strong> Translation source<\\/li>\\n<li><strong>[Update]<\\/strong> PHP version compatibility<\\/li>\\n<li><strong>[Update]<\\/strong> Dependency update which brings additional PHP compatibility<\\/li>\\n<li><strong>[Security]<\\/strong> TCPDF security update (which as evaluated could NOT have been exploited)<\\/li>\\n<\\/ul>\\n<p>3.0.4<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Handling of multiple word highlighting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better restriction during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Issue with Advanced Custom Fields repeater detection<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of cached data<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent unwanted indexer activity when using searchwp_indexed_post_types<\\/li>\\n<li><strong>[Change]<\\/strong> Removal of ACF field references is now opt-in<\\/li>\\n<li><strong>[Change]<\\/strong> searchwp_lenient_accents now applies during searches as well<\\/li>\\n<li><strong>[New]<\\/strong> Filter searchwp_lenient_accents_on_search to allow refined control over leinient accent treatment<\\/li>\\n<\\/ul>\\n<p>3.0.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with checking for unused meta keys when configuring search engines<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes a potential issue with searchwp_short_circuit being incorrectly overridden<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with synonyms not working as expected<\\/li>\\n<\\/ul>\\n<p>3.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue that may prevent Custom Fields from appearing in engine configuration<\\/li>\\n<\\/ul>\\n<p>3.0<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Advanced Settings screen rebuilt and optimized<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_legacy_advanced_settings filter controls whether the legacy Advanced Settings screen is used<\\/li>\\n<li><strong>[New]<\\/strong> Integrated stopword management on the Advanced Settings screen<\\/li>\\n<li><strong>[New]<\\/strong> Default stopwords for the following locales: CS, DA, DE, EN, ES, FI, GA, IT, NL, PL, PT, RO, RU, SV, TR<\\/li>\\n<li><strong>[New]<\\/strong> Suggested stopwords based on existing site content<\\/li>\\n<li><strong>[New]<\\/strong> Integrated Term Synonyms and improved management UI (extension is now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Integrated Term Highlight (extension is now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Integrated LIKE Terms and Fuzzy Matches (extensions are now deprecated)<\\/li>\\n<li><strong>[New]<\\/strong> Adds setting to parse Shortcodes during indexing (e.g. UI for searchwp_do_shortcodes)<\\/li>\\n<li><strong>[New]<\\/strong> SWP_Query now has the following methods: have_posts, rewind_posts, the_post, next_post allowing for a more traditional Loop<\\/li>\\n<li><strong>[New]<\\/strong> Custom Fields dropdown now supports meta groups<\\/li>\\n<li><strong>[New]<\\/strong> Automatic UI for \\"repeatable\\" field groups in Advanced Custom Fields<\\/li>\\n<li><strong>[New]<\\/strong> Statistics screen rebuilt and optimized<\\/li>\\n<li><strong>[New]<\\/strong> Management of ignored searches is now built in to the Stats screen<\\/li>\\n<li><strong>[New]<\\/strong> Resetting of statistics is now built in to the Stats screen<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_statistics_popular_days_{$days} filter allows overriding of popular search queries<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_legacy_stats filter controls whether the legacy Advanced Settings screen is used<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_results_found_posts filter allows modification of SearchWP\'s found posts<\\/li>\\n<li><strong>[New]<\\/strong> searchwp_results_max_num_pages filter allows modification of SearchWP\'s maximum number of pages<\\/li>\\n<li><strong>[New]<\\/strong> Support for programmatic license management. See SearchWP_License class<\\/li>\\n<li><strong>[New]<\\/strong> Adds (dismiss-able) notice during admin searches when admin searches are not hijacked by SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> Adds support for WordPress\' block editor during indexing (blocks will be parsed prior to indexing)<\\/li>\\n<li><strong>[Fix]<\\/strong> Adds support for results limiting when parent attribution is enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of emoji during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent pattern whitelist matches from being counted twice<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent data mutation when creating multiple supplemental engines at once<\\/li>\\n<li><strong>[Change]<\\/strong> Indexing emoji is now opt-in using the searchwp_index_emoji filter<\\/li>\\n<\\/ul>\\n<p>2.9.17<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of post status and comment triggers of delta updates, reducing significant overhead in some cases<\\/li>\\n<\\/ul>\\n<p>2.9.16<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue that prevented proper respect of searchwp_background_deltas<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue with debug log permissions in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where Custom Field keys were not accurately retrieved in older versions of WordPress<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes settings screen JavaScript error in IE11<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue preventing the application of searchwp_search_query_order<\\/li>\\n<li><strong>[Improvement]<\\/strong> Notes the requirement that the index must be rebuilt after ticking checkbox to remove minimum character count<\\/li>\\n<li><strong>[New]<\\/strong> Adds post_status parameter to SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Adds order parameter to SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Adds limited orderby parameter to SWP_Query<\\/li>\\n<\\/ul>\\n<p>2.9.15<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where in some cases delta update requests were not processed correctly<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> The debug log generation process has been improved and the debug log more streamlined\\/readable<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_debug_detailed to control whether detailed items are logged when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.9.14<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes false positive error message relating to HTTP Basic Authentication<\\/li>\\n<li><strong>[Fix]<\\/strong> Resolves an issue preventing translations from loading as expected<\\/li>\\n<li><strong>[Change]<\\/strong> Algorithm SQL has been updated to be more specific when considering Custom Fields and Taxonomies<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_dashboard_widget_transient_ttl that allows for customization of cache duration of Dashboard Widget data<\\/li>\\n<\\/ul>\\n<p>2.9.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Prevent redundant statistics logging on paginated results when using SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of taxonomy terms with special characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning and PHP Notice in certain cases<\\/li>\\n<\\/ul>\\n<p>2.9.12<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Index better optimized when limiting to Media mime type<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic is more restrictive when applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of license key when provided via constant or filter<\\/li>\\n<li><strong>[Update]<\\/strong> Updates translation source<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes inaccurate indexer progress in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes handling of All Documents mime type Media limiter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning<\\/li>\\n<\\/ul>\\n<p>2.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong>\\u00a0Additional index optimization when delta updates are applied via new filter searchwp_aggressive_delta_update<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug output cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Implements omitted filter argument<\\/li>\\n<\\/ul>\\n<p>2.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves an issue where AND logic wasn\'t strict enough in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Relocated searchwp_indexer_pre action trigger to restore expected behavior<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additinal refinements to delta update queue processing to prevent excessive server resource usage in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Adds edit icon to supplemental engine name to communicate it is editable<\\/li>\\n<li><strong>[Change]<\\/strong> License key is no longer displayed in license key field if populated via constant or hook<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_engine_use_taxonomy_name that controls displaying name or label of Taxonomies in enging settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_and_fields_{$post_type} allowing for AND field customization per post type<\\/li>\\n<\\/ul>\\n<p>2.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where post type Limit rules were too aggressive in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined index delta update routine to reduce potentially unnecessary triggers<\\/li>\\n<\\/ul>\\n<p>2.9.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves issue of inaccurate results count when parent attribution is in effect<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better processing of engine Rules during indexing<\\/li>\\n<\\/ul>\\n<p>2.9.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed link in admin notice<\\/li>\\n<\\/ul>\\n<p>2.9.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue causing newly regiestered taxonomies to be unavailable in settings UI<\\/li>\\n<li><strong>[Fix]<\\/strong> Messaging for index being out of date is now more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Paged searches are no longer redundantly logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default regex patterns by making them more strict<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing libraries<\\/li>\\n<\\/ul>\\n<p>2.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any Custom Field\' did not work as expected in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomies added since the last engine save may not be available<\\/li>\\n<li><strong>[Improvement]<\\/strong> Actual weight multiplier is displayed in tooltip<\\/li>\\n<\\/ul>\\n<p>2.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS bug causing multiselect overlapping when configuring multiple post types<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue preventing searches of hierarchical post types in the admin<\\/li>\\n<\\/ul>\\n<p>2.9.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a searchwp_and_logic_only regression introduced in 2.9<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial default engine model<\\/li>\\n<\\/ul>\\n<p>2.9.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with some custom ORDER BY statements<\\/li>\\n<\\/ul>\\n<p>2.9.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with sql_mode=only_full_group_by support (added in 2.9)<\\/li>\\n<li><strong>[Fix]<\\/strong> Avoid error when parsing PDFs without mbstring<\\/li>\\n<\\/ul>\\n<p>2.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Redesigned engine configuration interface!<\\/li>\\n<li><strong>[New]<\\/strong> Index is now further optimized as per engine settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_max to customize a maximum weight<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_legacy_settings_ui to use legacy settings UI<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_apply_engines_rules to control whether engine rules are considered during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_additional_meta_exclusions to control whether default additional Custom Fields are excluded from indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_supports_label_{post_type}_{support} to customize the label used for a post type native attribute<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional debug statements output when enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better formatting of HTML comment debug output<\\/li>\\n<li><strong>[Fix]<\\/strong> Less aggressive handling of pre_get_posts during searching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix an issue with sql_mode=only_full_group_by (default in MySQL 5.7)<\\/li>\\n<\\/ul>\\n<p>For older versions please see <a href=\\"https:\\/\\/searchwp.com\\/docs\\/changelog-archive\\/\\" target=\\"_blank\\" rel=\\"noopener\\">the changelog archive<\\/a><\\/p>\\n"]}";}', 'no'),
(234, 'sm_options', 'a:52:{s:18:"sm_b_prio_provider";s:41:"GoogleSitemapGeneratorPrioByCountProvider";s:9:"sm_b_ping";b:1;s:10:"sm_b_stats";b:0;s:12:"sm_b_pingmsn";b:1;s:12:"sm_b_autozip";b:1;s:11:"sm_b_memory";s:0:"";s:9:"sm_b_time";i:-1;s:18:"sm_b_style_default";b:1;s:10:"sm_b_style";s:0:"";s:12:"sm_b_baseurl";s:0:"";s:11:"sm_b_robots";b:1;s:9:"sm_b_html";b:1;s:12:"sm_b_exclude";a:0:{}s:17:"sm_b_exclude_cats";a:0:{}s:10:"sm_in_home";b:1;s:11:"sm_in_posts";b:1;s:15:"sm_in_posts_sub";b:0;s:11:"sm_in_pages";b:1;s:10:"sm_in_cats";b:0;s:10:"sm_in_arch";b:0;s:10:"sm_in_auth";b:0;s:10:"sm_in_tags";b:0;s:9:"sm_in_tax";a:0:{}s:17:"sm_in_customtypes";a:0:{}s:13:"sm_in_lastmod";b:1;s:10:"sm_cf_home";s:5:"daily";s:11:"sm_cf_posts";s:7:"monthly";s:11:"sm_cf_pages";s:6:"weekly";s:10:"sm_cf_cats";s:6:"weekly";s:10:"sm_cf_auth";s:6:"weekly";s:15:"sm_cf_arch_curr";s:5:"daily";s:14:"sm_cf_arch_old";s:6:"yearly";s:10:"sm_cf_tags";s:6:"weekly";s:10:"sm_pr_home";d:1;s:11:"sm_pr_posts";d:0.6;s:15:"sm_pr_posts_min";d:0.2;s:11:"sm_pr_pages";d:0.6;s:10:"sm_pr_cats";d:0.3;s:10:"sm_pr_arch";d:0.3;s:10:"sm_pr_auth";d:0.3;s:10:"sm_pr_tags";d:0.3;s:12:"sm_i_donated";b:0;s:17:"sm_i_hide_donated";b:0;s:17:"sm_i_install_date";i:1584893363;s:16:"sm_i_hide_survey";b:1;s:14:"sm_i_hide_note";b:0;s:15:"sm_i_hide_works";b:0;s:16:"sm_i_hide_donors";b:0;s:9:"sm_i_hash";s:20:"e0619bbc595c289fc482";s:13:"sm_i_lastping";i:1585081735;s:16:"sm_i_supportfeed";b:1;s:22:"sm_i_supportfeed_cache";i:1584904213;}', 'yes'),
(235, 'sm_status', 'O:28:"GoogleSitemapGeneratorStatus":8:{s:39:"\0GoogleSitemapGeneratorStatus\0startTime";d:1585081734.00975;s:37:"\0GoogleSitemapGeneratorStatus\0endTime";d:1585081734.438904;s:41:"\0GoogleSitemapGeneratorStatus\0pingResults";a:2:{s:6:"google";a:5:{s:9:"startTime";d:1585081734.011372;s:7:"endTime";d:1585081734.322979;s:7:"success";b:0;s:3:"url";s:100:"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Flocalhost%2Fnousot%2Fsitemap.xml";s:4:"name";s:6:"Google";}s:4:"bing";a:5:{s:9:"startTime";d:1585081734.323994;s:7:"endTime";d:1585081734.434278;s:7:"success";b:1;s:3:"url";s:93:"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2Flocalhost%2Fnousot%2Fsitemap.xml";s:4:"name";s:4:"Bing";}}s:38:"\0GoogleSitemapGeneratorStatus\0autoSave";b:1;s:9:"startTime";d:1585081734.00975;s:7:"endTime";d:1585081734.438904;s:11:"pingResults";a:2:{s:6:"google";a:5:{s:9:"startTime";d:1585081734.011372;s:7:"endTime";d:1585081734.322979;s:7:"success";b:0;s:3:"url";s:100:"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Flocalhost%2Fnousot%2Fsitemap.xml";s:4:"name";s:6:"Google";}s:4:"bing";a:5:{s:9:"startTime";d:1585081734.323994;s:7:"endTime";d:1585081734.434278;s:7:"success";b:1;s:3:"url";s:93:"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2Flocalhost%2Fnousot%2Fsitemap.xml";s:4:"name";s:4:"Bing";}}s:8:"autoSave";b:1;}', 'no'),
(236, 'WPLANG', '', 'yes'),
(237, 'new_admin_email', 'erica@ericadreisbach.com', 'yes'),
(345, 'searchwp_waiting', '', 'no'),
(346, 'searchwp_transient', '1585081718.5693700313568115234375', 'no'),
(362, 'category_children', 'a:0:{}', 'yes'),
(365, 'searchwp_doing_delta', '', 'no'),
(366, 'swppurge_transient', '1585081718.0695590972900390625000', 'no'),
(434, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1585164686;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 3, '_edit_lock', '1585077590:1'),
(4, 3, '_wp_suggested_privacy_policy_content', 'a:3:{s:11:"plugin_name";s:9:"WordPress";s:11:"policy_text";s:11782:"<div class="wp-suggested-text"><h2>Who we are</h2><p class="privacy-policy-tutorial">In this section you should note your site URL, as well as the name of the company, organization, or individual behind it, and some accurate contact information.</p><p class="privacy-policy-tutorial">The amount of information you may be required to show will vary depending on your local or national business regulations. You may, for example, be required to display a physical address, a registered address, or your company registration number.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/nousot.</p><h2>What personal data we collect and why we collect it</h2><p class="privacy-policy-tutorial">In this section you should note what personal data you collect from users and site visitors. This may include personal data, such as name, email address, personal account preferences; transactional data, such as purchase information; and technical data, such as information about cookies.</p><p class="privacy-policy-tutorial">You should also note any collection and retention of sensitive personal data, such as data concerning health.</p><p class="privacy-policy-tutorial">In addition to listing what personal data you collect, you need to note why you collect it. These explanations must note either the legal basis for your data collection and retention or the active consent the user has given.</p><p class="privacy-policy-tutorial">Personal data is not just created by a user&#8217;s interactions with your site. Personal data is also generated from technical processes such as contact forms, comments, cookies, analytics, and third party embeds.</p><p class="privacy-policy-tutorial">By default WordPress does not collect any personal data about visitors, and only collects the data shown on the User Profile screen from registered users. However some of your plugins may collect personal data. You should add the relevant information below.</p><h3>Comments</h3><p class="privacy-policy-tutorial">In this subsection you should note what information is captured through comments. We have noted the data which WordPress collects by default.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p class="privacy-policy-tutorial">In this subsection you should note what information may be disclosed by users who can upload media files. All uploaded files are usually publicly accessible.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><p class="privacy-policy-tutorial">By default, WordPress does not include a contact form. If you use a contact form plugin, use this subsection to note what personal data is captured when someone submits a contact form, and how long you keep it. For example, you may note that you keep contact form submissions for a certain period for customer service purposes, but you do not use the information submitted through them for marketing purposes.</p><h3>Cookies</h3><p class="privacy-policy-tutorial">In this subsection you should list the cookies your web site uses, including those set by your plugins, social media, and analytics. We have provided the cookies which WordPress installs by default.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><p class="privacy-policy-tutorial">In this subsection you should note what analytics package you use, how users can opt out of analytics tracking, and a link to your analytics provider&#8217;s privacy policy, if any.</p><p class="privacy-policy-tutorial">By default WordPress does not collect any analytics data. However, many web hosting accounts collect some anonymous analytics data. You may also have installed a WordPress plugin that provides analytics services. In that case, add information from that plugin here.</p><h2>Who we share your data with</h2><p class="privacy-policy-tutorial">In this section you should name and list all third party providers with whom you share site data, including partners, cloud-based services, payment processors, and third party service providers, and note what data you share with them and why. Link to their own privacy policies if possible.</p><p class="privacy-policy-tutorial">By default WordPress does not share any personal data with anyone.</p><h2>How long we retain your data</h2><p class="privacy-policy-tutorial">In this section you should explain how long you retain personal data collected or processed by the web site. While it is your responsibility to come up with the schedule of how long you keep each dataset for and why you keep it, that information does need to be listed here. For example, you may want to say that you keep contact form entries for six months, analytics records for a year, and customer purchase records for ten years.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p class="privacy-policy-tutorial">In this section you should explain what rights your users have over their data and how they can invoke those rights.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p class="privacy-policy-tutorial">In this section you should list all transfers of your site data outside the European Union and describe the means by which that data is safeguarded to European data protection standards. This could include your web hosting, cloud storage, or other third party services.</p><p class="privacy-policy-tutorial">European data protection law requires data about European residents which is transferred outside the European Union to be safeguarded to the same standards as if the data was in Europe. So in addition to listing where data goes, you should describe how you ensure that these standards are met either by yourself or by your third party providers, whether that is through an agreement such as Privacy Shield, model clauses in your contracts, or binding corporate rules.</p><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><p class="privacy-policy-tutorial">In this section you should provide a contact method for privacy-specific concerns. If you are required to have a Data Protection Officer, list their name and full contact details here as well.</p><h2>Additional information</h2><p class="privacy-policy-tutorial">If you use your site for commercial purposes and you engage in more complex collection or processing of personal data, you should note the following information in your privacy policy in addition to the information we have already discussed.</p><h3>How we protect your data</h3><p class="privacy-policy-tutorial">In this section you should explain what measures you have taken to protect your users&#8217; data. This could include technical measures such as encryption; security measures such as two factor authentication; and measures such as staff training in data protection. If you have carried out a Privacy Impact Assessment, you can mention it here too.</p><h3>What data breach procedures we have in place</h3><p class="privacy-policy-tutorial">In this section you should explain what procedures you have in place to deal with data breaches, either potential or real, such as internal reporting systems, contact mechanisms, or bug bounties.</p><h3>What third parties we receive data from</h3><p class="privacy-policy-tutorial">If your web site receives data about users from third parties, including advertisers, this information must be included within the section of your privacy policy dealing with third party data.</p><h3>What automated decision making and/or profiling we do with user data</h3><p class="privacy-policy-tutorial">If your web site provides a service which includes automated decision making - for example, allowing customers to apply for credit, or aggregating their data into an advertising profile - you must note that this is taking place, and include information about how that information is used, what decisions are made with that aggregated data, and what rights users have over decisions made without human intervention.</p><h3>Industry regulatory disclosure requirements</h3><p class="privacy-policy-tutorial">If you are a member of a regulated industry, or if you are subject to additional privacy laws, you may be required to disclose that information here.</p></div>";s:5:"added";i:1581990911;}'),
(5, 3, '_edit_last', '1'),
(6, 8, '_menu_item_type', 'custom'),
(7, 8, '_menu_item_menu_item_parent', '0'),
(8, 8, '_menu_item_object_id', '8'),
(9, 8, '_menu_item_object', 'custom'),
(10, 8, '_menu_item_target', ''),
(11, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(12, 8, '_menu_item_xfn', ''),
(13, 8, '_menu_item_url', 'https://twitter.com'),
(15, 9, '_menu_item_type', 'custom'),
(16, 9, '_menu_item_menu_item_parent', '0'),
(17, 9, '_menu_item_object_id', '9'),
(18, 9, '_menu_item_object', 'custom'),
(19, 9, '_menu_item_target', ''),
(20, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(21, 9, '_menu_item_xfn', ''),
(22, 9, '_menu_item_url', 'https://www.linkedin.com/'),
(33, 11, '_wp_attached_file', '2020/03/logo.svg'),
(34, 11, '_wp_attachment_metadata', 'a:4:{s:5:"width";i:120;s:6:"height";i:120;s:4:"file";s:17:"/2020/03/logo.svg";s:5:"sizes";a:10:{s:9:"thumbnail";a:5:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:6:"medium";a:5:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"medium_large";a:5:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:5:"large";a:5:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"1536x1536";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"2048x2048";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:4:"hero";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:5:"small";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:6:"square";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:11:"custom-size";a:5:{s:5:"width";b:0;s:6:"height";b:0;s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}}}'),
(35, 2, '_edit_lock', '1584907458:1'),
(36, 13, '_wp_attached_file', '2020/03/fire-planet-3281255.jpg'),
(37, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:600;s:4:"file";s:31:"2020/03/fire-planet-3281255.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:31:"fire-planet-3281255-250x100.jpg";s:5:"width";i:250;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"fire-planet-3281255-700x280.jpg";s:5:"width";i:700;s:6:"height";i:280;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:31:"fire-planet-3281255-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"fire-planet-3281255-768x307.jpg";s:5:"width";i:768;s:6:"height";i:307;s:9:"mime-type";s:10:"image/jpeg";}s:4:"hero";a:4:{s:4:"file";s:32:"fire-planet-3281255-1500x570.jpg";s:5:"width";i:1500;s:6:"height";i:570;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"fire-planet-3281255-120x48.jpg";s:5:"width";i:120;s:6:"height";i:48;s:9:"mime-type";s:10:"image/jpeg";}s:6:"square";a:4:{s:4:"file";s:31:"fire-planet-3281255-400x400.jpg";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:11:"custom-size";a:4:{s:4:"file";s:31:"fire-planet-3281255-700x200.jpg";s:5:"width";i:700;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(38, 2, 'inline_featured_image', '0'),
(39, 2, '_edit_last', '1'),
(40, 15, 'inline_featured_image', '0'),
(41, 15, '_edit_lock', '1584893324:1'),
(42, 17, 'inline_featured_image', '0'),
(43, 17, '_edit_lock', '1585077783:1'),
(44, 18, '_wp_attached_file', '2020/03/hands.jpg'),
(45, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:17:"2020/03/hands.jpg";s:5:"sizes";a:5:{s:6:"medium";a:4:{s:4:"file";s:17:"hands-250x250.jpg";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:17:"hands-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:17:"hands-120x120.jpg";s:5:"width";i:120;s:6:"height";i:120;s:9:"mime-type";s:10:"image/jpeg";}s:6:"square";a:4:{s:4:"file";s:17:"hands-400x400.jpg";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:11:"custom-size";a:4:{s:4:"file";s:17:"hands-500x200.jpg";s:5:"width";i:500;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(46, 17, '_edit_last', '1'),
(47, 17, '_wp_page_template', 'default'),
(48, 23, '_menu_item_type', 'post_type'),
(49, 23, '_menu_item_menu_item_parent', '0'),
(50, 23, '_menu_item_object_id', '2'),
(51, 23, '_menu_item_object', 'page'),
(52, 23, '_menu_item_target', ''),
(53, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(54, 23, '_menu_item_xfn', ''),
(55, 23, '_menu_item_url', ''),
(57, 24, '_menu_item_type', 'post_type'),
(58, 24, '_menu_item_menu_item_parent', '0'),
(59, 24, '_menu_item_object_id', '15'),
(60, 24, '_menu_item_object', 'page'),
(61, 24, '_menu_item_target', ''),
(62, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(63, 24, '_menu_item_xfn', ''),
(64, 24, '_menu_item_url', ''),
(66, 25, '_menu_item_type', 'post_type'),
(67, 25, '_menu_item_menu_item_parent', '0'),
(68, 25, '_menu_item_object_id', '17'),
(69, 25, '_menu_item_object', 'page'),
(70, 25, '_menu_item_target', ''),
(71, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(72, 25, '_menu_item_xfn', ''),
(73, 25, '_menu_item_url', ''),
(75, 26, 'inline_featured_image', '0'),
(76, 26, '_edit_lock', '1584910586:1'),
(77, 28, '_menu_item_type', 'post_type'),
(78, 28, '_menu_item_menu_item_parent', '0'),
(79, 28, '_menu_item_object_id', '26'),
(80, 28, '_menu_item_object', 'page'),
(81, 28, '_menu_item_target', ''),
(82, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(83, 28, '_menu_item_xfn', ''),
(84, 28, '_menu_item_url', ''),
(86, 29, 'inline_featured_image', '0'),
(87, 29, '_edit_lock', '1584911155:1'),
(88, 31, '_menu_item_type', 'post_type'),
(89, 31, '_menu_item_menu_item_parent', '0'),
(90, 31, '_menu_item_object_id', '29'),
(91, 31, '_menu_item_object', 'page'),
(92, 31, '_menu_item_target', ''),
(93, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(94, 31, '_menu_item_xfn', ''),
(95, 31, '_menu_item_url', ''),
(97, 32, 'inline_featured_image', '0'),
(98, 32, '_edit_lock', '1584911176:1'),
(99, 34, 'inline_featured_image', '0'),
(100, 34, '_edit_lock', '1585063890:1'),
(101, 36, '_menu_item_type', 'post_type'),
(102, 36, '_menu_item_menu_item_parent', '25'),
(103, 36, '_menu_item_object_id', '34'),
(104, 36, '_menu_item_object', 'page'),
(105, 36, '_menu_item_target', ''),
(106, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 36, '_menu_item_xfn', ''),
(108, 36, '_menu_item_url', ''),
(110, 37, '_menu_item_type', 'post_type'),
(111, 37, '_menu_item_menu_item_parent', '25'),
(112, 37, '_menu_item_object_id', '32'),
(113, 37, '_menu_item_object', 'page'),
(114, 37, '_menu_item_target', ''),
(115, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(116, 37, '_menu_item_xfn', ''),
(117, 37, '_menu_item_url', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(119, 38, '_menu_item_type', 'custom'),
(120, 38, '_menu_item_menu_item_parent', '0'),
(121, 38, '_menu_item_object_id', '38'),
(122, 38, '_menu_item_object', 'custom'),
(123, 38, '_menu_item_target', ''),
(124, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(125, 38, '_menu_item_xfn', ''),
(126, 38, '_menu_item_url', '#search'),
(127, 38, '_menu_item_orphaned', '1584911411'),
(136, 40, 'inline_featured_image', '0'),
(137, 40, '_edit_lock', '1585080942:1'),
(138, 40, '_wp_page_template', 'page-login.php'),
(139, 42, '_menu_item_type', 'custom'),
(140, 42, '_menu_item_menu_item_parent', '0'),
(141, 42, '_menu_item_object_id', '42'),
(142, 42, '_menu_item_object', 'custom'),
(143, 42, '_menu_item_target', ''),
(144, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(145, 42, '_menu_item_xfn', ''),
(146, 42, '_menu_item_url', 'mailto:email@domain.com'),
(149, 1, '_searchwp_last_index', '1585047515'),
(151, 34, '_searchwp_last_index', '1585047518'),
(153, 32, '_searchwp_last_index', '1585047518'),
(155, 29, '_searchwp_last_index', '1585047518'),
(157, 26, '_searchwp_last_index', '1585047518'),
(161, 15, '_searchwp_last_index', '1585047518'),
(163, 2, '_searchwp_last_index', '1585047518'),
(164, 3, 'inline_featured_image', '0'),
(166, 3, '_searchwp_last_index', '1585059736'),
(168, 17, '_searchwp_last_index', '1585059937'),
(169, 46, '_edit_last', '1'),
(170, 46, '_edit_lock', '1585080785:1'),
(171, 40, '_edit_last', '1'),
(172, 49, 'inline_featured_image', '0'),
(173, 49, '_edit_lock', '1585081568:1'),
(176, 52, '_wp_attached_file', '2020/03/beijing.jpg'),
(177, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:700;s:6:"height";i:700;s:4:"file";s:19:"2020/03/beijing.jpg";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:19:"beijing-250x250.jpg";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"beijing-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:4:"hero";a:4:{s:4:"file";s:19:"beijing-700x570.jpg";s:5:"width";i:700;s:6:"height";i:570;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:19:"beijing-120x120.jpg";s:5:"width";i:120;s:6:"height";i:120;s:9:"mime-type";s:10:"image/jpeg";}s:6:"square";a:4:{s:4:"file";s:19:"beijing-400x400.jpg";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:11:"custom-size";a:4:{s:4:"file";s:19:"beijing-700x200.jpg";s:5:"width";i:700;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(178, 62, 'inline_featured_image', '0'),
(179, 62, '_edit_lock', '1585081713:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2020-02-07 01:32:13', '2020-02-07 01:32:13', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2020-02-07 01:32:13', '2020-02-07 01:32:13', '', 0, 'http://localhost/nousot/?p=1', 0, 'post', '', 1),
(2, 1, '2020-02-07 01:32:13', '2020-02-07 07:32:13', '<!-- wp:cover {"url":"http://localhost/nousot/wp-content/uploads/2020/03/fire-planet-3281255.jpg","id":13} -->\n<div class="wp-block-cover has-background-dim" style="background-image:url(http://localhost/nousot/wp-content/uploads/2020/03/fire-planet-3281255.jpg)"><div class="wp-block-cover__inner-container"><!-- wp:heading {"level":1} -->\n<h1>Home</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Learn more about us</h2>\n<!-- /wp:heading --></div></div>\n<!-- /wp:cover -->', 'Home', '', 'publish', 'closed', 'closed', '', 'sample-page', '', '', '2020-03-22 11:10:44', '2020-03-22 16:10:44', '', 0, 'http://localhost/nousot/?page_id=2', 1, 'page', '', 0),
(3, 1, '2020-02-07 01:32:13', '2020-02-07 01:32:13', '<!-- wp:heading -->\n<h2>Who we are</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Our website address is: http://localhost/nousot.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>What personal data we collect and why we collect it</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Comments</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Media</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Contact forms</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Cookies</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select "Remember Me", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Embedded content from other websites</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Analytics</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Who we share your data with</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>How long we retain your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>What rights you have over your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Where we send your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Your contact information</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Additional information</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>How we protect your data</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What data breach procedures we have in place</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What third parties we receive data from</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What automated decision making and/or profiling we do with user data</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Industry regulatory disclosure requirements</h3>\n<!-- /wp:heading -->', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2020-03-24 14:22:13', '2020-03-24 19:22:13', '', 0, 'http://localhost/nousot/?page_id=3', 900, 'page', '', 0),
(6, 1, '2020-03-22 15:20:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-22 15:20:07', '0000-00-00 00:00:00', '', 0, 'http://localhost/nousot/?p=6', 0, 'post', '', 0),
(7, 1, '2020-03-22 15:43:14', '2020-03-22 15:43:14', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost/nousot.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2020-03-22 15:43:14', '2020-03-22 15:43:14', '', 3, 'http://localhost/nousot/2020/03/22/3-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2020-03-22 15:45:25', '2020-03-22 15:45:25', '', '@twitter', '', 'publish', 'closed', 'closed', '', 'twitter', '', '', '2020-03-24 10:37:19', '2020-03-24 15:37:19', '', 0, 'http://localhost/nousot/?p=8', 1, 'nav_menu_item', '', 0),
(9, 1, '2020-03-22 15:45:25', '2020-03-22 15:45:25', '', 'linkedin.com/li/user', '', 'publish', 'closed', 'closed', '', 'linkedin-com-li-user', '', '', '2020-03-24 10:37:19', '2020-03-24 15:37:19', '', 0, 'http://localhost/nousot/?p=9', 2, 'nav_menu_item', '', 0),
(11, 1, '2020-03-22 15:49:41', '2020-03-22 15:49:41', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2020-03-22 15:49:41', '2020-03-22 15:49:41', '', 0, 'http://localhost/nousot/wp-content/uploads/2020/03/logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(13, 1, '2020-03-22 16:08:38', '2020-03-22 16:08:38', '', 'fire-planet-3281255', '', 'inherit', 'open', 'closed', '', 'fire-planet-3281255', '', '', '2020-03-22 16:08:38', '2020-03-22 16:08:38', '', 2, 'http://localhost/nousot/wp-content/uploads/2020/03/fire-planet-3281255.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2020-03-22 16:09:14', '2020-03-22 16:09:14', '<!-- wp:cover {"url":"http://localhost/nousot/wp-content/uploads/2020/03/fire-planet-3281255.jpg","id":13} -->\n<div class="wp-block-cover has-background-dim" style="background-image:url(http://localhost/nousot/wp-content/uploads/2020/03/fire-planet-3281255.jpg)"><div class="wp-block-cover__inner-container"><!-- wp:heading {"level":1} -->\n<h1>Home</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Learn more about us</h2>\n<!-- /wp:heading --></div></div>\n<!-- /wp:cover -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2020-03-22 16:09:14', '2020-03-22 16:09:14', '', 2, 'http://localhost/nousot/2020/03/22/2-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2020-03-22 11:11:14', '2020-03-22 16:11:14', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2020-03-22 11:11:14', '2020-03-22 16:11:14', '', 0, 'http://localhost/nousot/?page_id=15', 2, 'page', '', 0),
(16, 1, '2020-03-22 11:11:14', '2020-03-22 16:11:14', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2020-03-22 11:11:14', '2020-03-22 16:11:14', '', 15, 'http://localhost/nousot/2020/03/22/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2020-03-22 11:14:36', '2020-03-22 16:14:36', '<!-- wp:media-text {"mediaId":18,"mediaType":"image","isStackedOnMobile":true,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2020-03-24 14:25:25', '2020-03-24 19:25:25', '', 0, 'http://localhost/nousot/?page_id=17', 3, 'page', '', 0),
(18, 1, '2020-03-22 11:14:32', '2020-03-22 16:14:32', '', 'hands', '', 'inherit', 'open', 'closed', '', 'hands', '', '', '2020-03-22 11:14:32', '2020-03-22 16:14:32', '', 17, 'http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2020-03-22 11:14:36', '2020-03-22 16:14:36', '<!-- wp:media-text {"mediaId":18,"mediaType":"image"} -->\n<div class="wp-block-media-text alignwide"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-22 11:14:36', '2020-03-22 16:14:36', '', 17, 'http://localhost/nousot/2020/03/22/17-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2020-03-22 15:05:24', '2020-03-22 20:05:24', '<!-- wp:media-text {"mediaId":18,"mediaType":"image","isStackedOnMobile":true} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-22 15:05:24', '2020-03-22 20:05:24', '', 17, 'http://localhost/nousot/2020/03/22/17-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2020-03-22 15:06:59', '2020-03-22 20:06:59', '<!-- wp:media-text {"mediaId":18,"mediaType":"image","mediaWidth":70,"isStackedOnMobile":true} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile" style="grid-template-columns:70% auto"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-22 15:06:59', '2020-03-22 20:06:59', '', 17, 'http://localhost/nousot/2020/03/22/17-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2020-03-22 15:31:33', '2020-03-22 20:31:33', '<!-- wp:media-text {"mediaId":18,"mediaType":"image","mediaWidth":56,"isStackedOnMobile":true} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile" style="grid-template-columns:56% auto"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-22 15:31:33', '2020-03-22 20:31:33', '', 17, 'http://localhost/nousot/2020/03/22/17-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2020-03-22 15:53:52', '2020-03-22 20:53:52', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 0, 'http://localhost/nousot/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2020-03-22 15:53:52', '2020-03-22 20:53:52', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 0, 'http://localhost/nousot/?p=24', 2, 'nav_menu_item', '', 0),
(25, 1, '2020-03-22 15:53:52', '2020-03-22 20:53:52', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 0, 'http://localhost/nousot/?p=25', 3, 'nav_menu_item', '', 0),
(26, 1, '2020-03-22 15:58:28', '2020-03-22 20:58:28', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2020-03-22 15:58:28', '2020-03-22 20:58:28', '', 0, 'http://localhost/nousot/?page_id=26', 4, 'page', '', 0),
(27, 1, '2020-03-22 15:58:28', '2020-03-22 20:58:28', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2020-03-22 15:58:28', '2020-03-22 20:58:28', '', 26, 'http://localhost/nousot/2020/03/22/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2020-03-22 15:59:16', '2020-03-22 20:59:16', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 0, 'http://localhost/nousot/?p=28', 6, 'nav_menu_item', '', 0),
(29, 1, '2020-03-22 15:59:26', '2020-03-22 20:59:26', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2020-03-22 15:59:26', '2020-03-22 20:59:26', '', 0, 'http://localhost/nousot/?page_id=29', 5, 'page', '', 0),
(30, 1, '2020-03-22 15:59:26', '2020-03-22 20:59:26', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2020-03-22 15:59:26', '2020-03-22 20:59:26', '', 29, 'http://localhost/nousot/2020/03/22/29-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2020-03-22 15:59:33', '2020-03-22 20:59:33', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 0, 'http://localhost/nousot/?p=31', 7, 'nav_menu_item', '', 0),
(32, 1, '2020-03-22 16:08:37', '2020-03-22 21:08:37', '', 'Event Planning', '', 'publish', 'closed', 'closed', '', 'event-planning', '', '', '2020-03-22 16:08:37', '2020-03-22 21:08:37', '', 17, 'http://localhost/nousot/?page_id=32', 1, 'page', '', 0),
(33, 1, '2020-03-22 16:08:37', '2020-03-22 21:08:37', '', 'Event Planning', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2020-03-22 16:08:37', '2020-03-22 21:08:37', '', 32, 'http://localhost/nousot/2020/03/22/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2020-03-22 16:08:54', '2020-03-22 21:08:54', '', 'Marketing Materials', '', 'publish', 'closed', 'closed', '', 'marketing-materials', '', '', '2020-03-22 16:08:54', '2020-03-22 21:08:54', '', 17, 'http://localhost/nousot/?page_id=34', 2, 'page', '', 0),
(35, 1, '2020-03-22 16:08:54', '2020-03-22 21:08:54', '', 'Marketing Materials', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2020-03-22 16:08:54', '2020-03-22 21:08:54', '', 34, 'http://localhost/nousot/2020/03/22/34-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2020-03-22 16:09:12', '2020-03-22 21:09:12', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 17, 'http://localhost/nousot/?p=36', 5, 'nav_menu_item', '', 0),
(37, 1, '2020-03-22 16:09:12', '2020-03-22 21:09:12', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2020-03-22 16:10:18', '2020-03-22 21:10:18', '', 17, 'http://localhost/nousot/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2020-03-22 16:10:11', '0000-00-00 00:00:00', '', 'Search', '', 'draft', 'closed', 'closed', '', '', '', '', '2020-03-22 16:10:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/nousot/?p=38', 1, 'nav_menu_item', '', 0),
(40, 1, '2020-03-24 10:33:30', '2020-03-24 15:33:30', '', 'Log In', '', 'publish', 'closed', 'closed', '', 'admin-login', '', '', '2020-03-24 15:15:42', '2020-03-24 20:15:42', '', 0, 'http://localhost/nousot/?page_id=40', 800, 'page', '', 0),
(41, 1, '2020-03-24 10:33:30', '2020-03-24 15:33:30', '', 'Login', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2020-03-24 10:33:30', '2020-03-24 15:33:30', '', 40, 'http://localhost/nousot/2020/03/24/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2020-03-24 10:34:37', '2020-03-24 15:34:37', '', 'email [at] domain [dot] com', '', 'publish', 'closed', 'closed', '', 'email-at-domain-dot-com', '', '', '2020-03-24 10:37:19', '2020-03-24 15:37:19', '', 0, 'http://localhost/nousot/?p=42', 3, 'nav_menu_item', '', 0),
(43, 1, '2020-03-24 14:22:13', '2020-03-24 19:22:13', '<!-- wp:heading -->\n<h2>Who we are</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Our website address is: http://localhost/nousot.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>What personal data we collect and why we collect it</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Comments</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Media</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Contact forms</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Cookies</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select "Remember Me", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Embedded content from other websites</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Analytics</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Who we share your data with</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>How long we retain your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>What rights you have over your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Where we send your data</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Your contact information</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Additional information</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>How we protect your data</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What data breach procedures we have in place</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What third parties we receive data from</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>What automated decision making and/or profiling we do with user data</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>Industry regulatory disclosure requirements</h3>\n<!-- /wp:heading -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2020-03-24 14:22:13', '2020-03-24 19:22:13', '', 3, 'http://localhost/nousot/2020/03/24/3-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2020-03-24 14:22:24', '2020-03-24 19:22:24', '', 'Log In', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2020-03-24 14:22:24', '2020-03-24 19:22:24', '', 40, 'http://localhost/nousot/2020/03/24/40-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2020-03-24 14:25:25', '2020-03-24 19:25:25', '<!-- wp:media-text {"mediaId":18,"mediaType":"image","isStackedOnMobile":true,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"normal"} -->\n<p class="has-normal-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae purus et mauris iaculis bibendum a at justo. Aliquam pretium dui sed odio bibendum facilisis. In ultricies gravida ipsum, sit amet convallis leo egestas quis. Sed orci turpis, dictum posuere erat a, venenatis placerat orci. Praesent in magna ut nisl commodo aliquam nec at mauris. In lacinia interdum orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin laoreet sed dolor non placerat. Suspendisse neque ipsum, mollis quis sem id, dignissim laoreet lectus. Cras ullamcorper est eget nulla ornare, sit amet egestas ex mattis.</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Services', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-24 14:25:25', '2020-03-24 19:25:25', '', 17, 'http://localhost/nousot/2020/03/24/17-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2020-03-24 15:14:53', '2020-03-24 20:14:53', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Open Graph', 'open-graph', 'publish', 'closed', 'closed', '', 'group_5e7a6982c134c', '', '', '2020-03-24 15:15:09', '2020-03-24 20:15:09', '', 0, 'http://localhost/nousot/?post_type=acf-field-group&#038;p=46', 1, 'acf-field-group', '', 0),
(47, 1, '2020-03-24 15:14:53', '2020-03-24 20:14:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:314:"Recommended size: 1200px wide x 1200px high with focal point in the center. Image may be cropped to 1200px x 430px by social media platforms. This image is the default image that will programmatically appear when the site is shared on social media. Featured Image for a given post or page will override this image.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Social sharing image', 'social-img', 'publish', 'closed', 'closed', '', 'field_5e7a699e85619', '', '', '2020-03-24 15:14:53', '2020-03-24 20:14:53', '', 46, 'http://localhost/nousot/?post_type=acf-field&p=47', 0, 'acf-field', '', 0),
(48, 1, '2020-03-24 15:14:53', '2020-03-24 20:14:53', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:213:"Recommended: no more than 300 characters. This text is the default text that will programmatically appear when the site is shared on social media. Meta description for a given post or page will override this text.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Social sharing text', 'social-txt', 'publish', 'closed', 'closed', '', 'field_5e7a6a188561a', '', '', '2020-03-24 15:15:09', '2020-03-24 20:15:09', '', 46, 'http://localhost/nousot/?post_type=acf-field&#038;p=48', 1, 'acf-field', '', 0),
(49, 1, '2020-03-24 15:20:12', '2020-03-24 20:20:12', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:quote {"className":"corset"} -->\n<blockquote class="wp-block-quote corset"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:image {"align":"center","id":18,"width":500,"height":500,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large is-resized"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18" width="500" height="500"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'publish', 'closed', 'closed', '', 'kitchen-sink', '', '', '2020-03-24 15:28:37', '2020-03-24 20:28:37', '', 0, 'http://localhost/nousot/?page_id=49', 901, 'page', '', 0),
(50, 1, '2020-03-24 15:20:12', '2020-03-24 20:20:12', '<!-- wp:heading {"level":1} -->\n<h1>H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:20:12', '2020-03-24 20:20:12', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2020-03-24 15:27:15', '2020-03-24 20:27:15', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"align":"center","id":18,"width":500,"height":500,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large is-resized"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18" width="500" height="500"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-autosave-v1', '', '', '2020-03-24 15:27:15', '2020-03-24 20:27:15', '', 49, 'http://localhost/nousot/2020/03/24/49-autosave-v1/', 0, 'revision', '', 0),
(52, 1, '2020-03-24 15:23:04', '2020-03-24 20:23:04', '', 'beijing', '', 'inherit', 'open', 'closed', '', 'beijing', '', '', '2020-03-24 15:23:04', '2020-03-24 20:23:04', '', 49, 'http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2020-03-24 15:23:33', '2020-03-24 20:23:33', '<!-- wp:heading {"level":1} -->\n<h1>H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:23:33', '2020-03-24 20:23:33', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2020-03-24 15:23:53', '2020-03-24 20:23:53', '<!-- wp:heading {"level":1} -->\n<h1>H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:23:53', '2020-03-24 20:23:53', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(55, 1, '2020-03-24 15:24:07', '2020-03-24 20:24:07', '<!-- wp:heading {"level":1} -->\n<h1>H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"align":"center","id":18,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:24:07', '2020-03-24 20:24:07', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2020-03-24 15:24:21', '2020-03-24 20:24:21', '<!-- wp:heading {"level":1} -->\n<h1>H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large","className":"corset"} -->\n<figure class="wp-block-image size-large corset"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:24:21', '2020-03-24 20:24:21', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2020-03-24 15:24:46', '2020-03-24 20:24:46', '<!-- wp:heading {"level":1,"className":"corset"} -->\n<h1 class="corset">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"className":"corset"} -->\n<h2 class="corset">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3,"className":"cor"} -->\n<h3 class="cor">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":4} -->\n<h4>H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":5} -->\n<h5>H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":6} -->\n<h6>H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large","className":"corset"} -->\n<figure class="wp-block-image size-large corset"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:24:46', '2020-03-24 20:24:46', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2020-03-24 15:25:11', '2020-03-24 20:25:11', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":18,"sizeSlug":"large","className":"corset"} -->\n<figure class="wp-block-image size-large corset"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:25:11', '2020-03-24 20:25:11', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2020-03-24 15:25:54', '2020-03-24 20:25:54', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"align":"center","id":18,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:25:54', '2020-03-24 20:25:54', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2020-03-24 15:27:57', '2020-03-24 20:27:57', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote {"className":"corset"} -->\n<blockquote class="wp-block-quote corset"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"align":"center","id":18,"width":500,"height":500,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large is-resized"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18" width="500" height="500"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:27:57', '2020-03-24 20:27:57', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2020-03-24 15:28:25', '2020-03-24 20:28:25', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:quote {"className":"corset"} -->\n<blockquote class="wp-block-quote corset"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:image {"align":"center","id":18,"width":500,"height":500,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large is-resized"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18" width="500" height="500"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:28:25', '2020-03-24 20:28:25', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2020-03-24 15:28:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-24 15:28:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/nousot/?p=62', 0, 'post', '', 0),
(63, 1, '2020-03-24 15:28:37', '2020-03-24 20:28:37', '<!-- wp:heading {"align":"center","level":1} -->\n<h1 class="has-text-align-center">H1</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center"} -->\n<h2 class="has-text-align-center">H2</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":3} -->\n<h3 class="has-text-align-center">H3</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":4} -->\n<h4 class="has-text-align-center">H4</h4>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":5} -->\n<h5 class="has-text-align-center">H5</h5>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"align":"center","level":6} -->\n<h6 class="has-text-align-center">H6</h6>\n<!-- /wp:heading -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:quote {"className":"corset"} -->\n<blockquote class="wp-block-quote corset"><p>Within the four seas, all men are brothers.</p><cite>Confucius</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:image {"align":"center","id":18,"width":500,"height":500,"sizeSlug":"large","className":"corset"} -->\n<div class="wp-block-image corset"><figure class="aligncenter size-large is-resized"><img src="http://localhost/nousot/wp-content/uploads/2020/03/hands.jpg" alt="" class="wp-image-18" width="500" height="500"/><figcaption>This is the image caption <strong>bold</strong> <em>italic</em> and <a href="https://google.com" target="_blank" rel="noreferrer noopener" aria-label="a link (opens in a new tab)">a link</a></figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:spacer -->\n<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:media-text {"mediaId":52,"mediaType":"image","isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"className":"corset"} -->\n<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center corset"><figure class="wp-block-media-text__media"><img src="http://localhost/nousot/wp-content/uploads/2020/03/beijing.jpg" alt="" class="wp-image-52"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"placeholder":"Content…","fontSize":"large"} -->\n<p class="has-large-font-size">This is Media + Text</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Kitchen Sink', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2020-03-24 15:28:37', '2020-03-24 20:28:37', '', 49, 'http://localhost/nousot/2020/03/24/49-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_cf`
#

DROP TABLE IF EXISTS `wp_swp_cf`;


#
# Table structure of table `wp_swp_cf`
#

CREATE TABLE `wp_swp_cf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `metakey` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term` int(20) unsigned NOT NULL,
  `count` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `metakey` (`metakey`),
  KEY `term` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_cf`
#

#
# End of data contents of table `wp_swp_cf`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_index`
#

DROP TABLE IF EXISTS `wp_swp_index`;


#
# Table structure of table `wp_swp_index`
#

CREATE TABLE `wp_swp_index` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term` bigint(20) unsigned NOT NULL,
  `content` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment` bigint(20) unsigned NOT NULL DEFAULT '0',
  `excerpt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `slug` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `termindex` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_index`
#
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(1, 1, 0, 1, 0, 0, 1, 1),
(2, 2, 0, 1, 0, 0, 1, 1),
(3, 3, 1, 0, 0, 0, 0, 1),
(4, 4, 1, 0, 0, 0, 0, 1),
(5, 5, 1, 0, 0, 0, 0, 1),
(6, 6, 1, 0, 0, 0, 0, 1),
(7, 7, 1, 0, 0, 0, 0, 1),
(8, 8, 1, 0, 0, 0, 0, 1),
(9, 9, 1, 0, 0, 0, 0, 1),
(10, 10, 1, 0, 0, 0, 0, 1),
(11, 11, 1, 0, 0, 0, 0, 1),
(12, 12, 1, 0, 0, 0, 0, 1),
(13, 13, 1, 0, 0, 0, 0, 1),
(14, 14, 0, 0, 1, 0, 0, 1),
(15, 15, 0, 0, 1, 0, 0, 1),
(16, 16, 0, 0, 1, 0, 0, 1),
(17, 17, 0, 0, 1, 0, 0, 1),
(18, 18, 0, 0, 1, 0, 0, 1),
(19, 19, 0, 0, 1, 0, 0, 1),
(20, 20, 0, 0, 2, 0, 0, 1),
(21, 21, 0, 0, 1, 0, 0, 1),
(22, 22, 0, 0, 1, 0, 0, 1),
(23, 23, 0, 0, 1, 0, 0, 1),
(24, 24, 0, 0, 1, 0, 0, 1),
(25, 25, 0, 0, 1, 0, 0, 1),
(26, 26, 0, 0, 1, 0, 0, 1),
(27, 27, 0, 0, 1, 0, 0, 1),
(28, 28, 0, 0, 1, 0, 0, 1),
(29, 29, 0, 0, 1, 0, 0, 1),
(30, 30, 0, 1, 0, 0, 1, 34),
(31, 31, 0, 1, 0, 0, 1, 34),
(32, 32, 0, 1, 0, 0, 1, 32),
(33, 33, 0, 1, 0, 0, 1, 32),
(34, 34, 0, 1, 0, 0, 1, 29),
(35, 35, 0, 1, 0, 0, 1, 26),
(125, 37, 1, 0, 0, 0, 0, 15),
(126, 38, 3, 0, 0, 0, 0, 15),
(127, 39, 2, 0, 0, 0, 0, 15),
(128, 40, 3, 0, 0, 0, 0, 15),
(129, 41, 3, 0, 0, 0, 0, 15),
(130, 42, 1, 0, 0, 0, 0, 15),
(131, 43, 1, 0, 0, 0, 0, 15),
(132, 44, 1, 0, 0, 0, 0, 15),
(133, 45, 2, 0, 0, 0, 0, 15),
(134, 46, 1, 0, 0, 0, 0, 15),
(135, 47, 1, 0, 0, 0, 0, 15),
(136, 48, 2, 0, 0, 0, 0, 15),
(137, 49, 1, 0, 0, 0, 0, 15),
(138, 50, 2, 0, 0, 0, 0, 15),
(139, 51, 1, 0, 0, 0, 0, 15),
(140, 52, 2, 0, 0, 0, 0, 15),
(141, 53, 1, 0, 0, 0, 0, 15),
(142, 54, 1, 0, 0, 0, 0, 15),
(143, 55, 3, 0, 0, 0, 0, 15),
(144, 56, 1, 0, 0, 0, 0, 15),
(145, 57, 1, 0, 0, 0, 0, 15),
(146, 58, 1, 0, 0, 0, 0, 15),
(147, 59, 1, 0, 0, 0, 0, 15),
(148, 60, 1, 0, 0, 0, 0, 15),
(149, 61, 1, 0, 0, 0, 0, 15),
(150, 62, 2, 0, 0, 0, 0, 15),
(151, 63, 2, 0, 0, 0, 0, 15),
(152, 64, 3, 0, 0, 0, 0, 15),
(153, 65, 1, 0, 0, 0, 0, 15),
(154, 66, 1, 0, 0, 0, 0, 15),
(155, 67, 1, 0, 0, 0, 0, 15),
(156, 68, 1, 0, 0, 0, 0, 15),
(157, 69, 1, 0, 0, 0, 0, 15),
(158, 70, 2, 0, 0, 0, 0, 15),
(159, 71, 1, 0, 0, 0, 0, 15),
(160, 72, 1, 0, 0, 0, 0, 15),
(161, 73, 1, 0, 0, 0, 0, 15),
(162, 74, 1, 0, 0, 0, 0, 15),
(163, 75, 1, 0, 0, 0, 0, 15),
(164, 76, 1, 0, 0, 0, 0, 15),
(165, 77, 1, 0, 0, 0, 0, 15),
(166, 78, 1, 0, 0, 0, 0, 15),
(167, 79, 1, 0, 0, 0, 0, 15),
(168, 80, 1, 0, 0, 0, 0, 15),
(169, 81, 1, 0, 0, 0, 0, 15),
(170, 82, 1, 0, 0, 0, 0, 15),
(171, 83, 1, 0, 0, 0, 0, 15),
(172, 84, 2, 0, 0, 0, 0, 15),
(173, 85, 1, 0, 0, 0, 0, 15),
(174, 86, 1, 0, 0, 0, 0, 15),
(175, 87, 1, 0, 0, 0, 0, 15),
(176, 88, 1, 0, 0, 0, 0, 15),
(177, 89, 1, 0, 0, 0, 0, 15),
(178, 90, 2, 0, 0, 0, 0, 15),
(179, 91, 1, 0, 0, 0, 0, 15),
(180, 92, 1, 0, 0, 0, 0, 15),
(181, 93, 1, 0, 0, 0, 0, 15),
(182, 94, 1, 0, 0, 0, 0, 15),
(183, 95, 1, 0, 0, 0, 0, 15),
(184, 96, 1, 0, 0, 0, 0, 15),
(185, 97, 1, 0, 0, 0, 0, 15),
(186, 98, 1, 0, 0, 0, 0, 15),
(187, 99, 1, 0, 0, 0, 0, 15),
(188, 100, 1, 0, 0, 0, 0, 15),
(189, 101, 1, 0, 0, 0, 0, 15) ;
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(190, 102, 1, 0, 0, 0, 0, 15),
(191, 103, 1, 0, 0, 0, 0, 15),
(192, 11, 1, 0, 0, 0, 0, 15),
(193, 12, 1, 0, 0, 0, 0, 15),
(194, 13, 1, 0, 0, 0, 0, 15),
(195, 195, 1, 1, 0, 0, 0, 2),
(196, 196, 0, 0, 0, 0, 1, 2),
(197, 197, 0, 0, 0, 0, 1, 2),
(198, 198, 1, 0, 0, 0, 0, 2),
(199, 199, 1, 0, 0, 0, 0, 2),
(200, 200, 1, 0, 0, 0, 0, 2),
(201, 201, 1, 0, 0, 0, 0, 2),
(202, 11, 1, 0, 0, 0, 0, 2),
(203, 202, 1, 0, 0, 0, 0, 2),
(204, 13, 1, 0, 0, 0, 0, 2),
(205, 203, 1, 0, 0, 0, 0, 2),
(206, 204, 1, 0, 0, 0, 0, 2),
(207, 205, 1, 0, 0, 0, 0, 2),
(208, 117, 1, 0, 0, 0, 0, 2),
(209, 206, 1, 0, 0, 0, 0, 2),
(210, 207, 1, 0, 0, 0, 0, 2),
(211, 208, 1, 0, 0, 0, 0, 2),
(212, 209, 1, 0, 0, 0, 0, 2),
(213, 121, 1, 0, 0, 0, 0, 2),
(214, 210, 2, 1, 0, 0, 1, 3),
(215, 211, 1, 1, 0, 0, 1, 3),
(216, 212, 9, 0, 0, 0, 0, 3),
(217, 213, 4, 0, 0, 0, 0, 3),
(218, 104, 1, 0, 0, 0, 0, 3),
(219, 105, 1, 0, 0, 0, 0, 3),
(220, 106, 1, 0, 0, 0, 0, 3),
(221, 214, 7, 0, 0, 0, 0, 3),
(222, 215, 19, 0, 0, 0, 0, 3),
(223, 216, 4, 0, 0, 0, 0, 3),
(224, 20, 6, 0, 0, 0, 0, 3),
(225, 217, 2, 0, 0, 0, 0, 3),
(226, 218, 4, 0, 0, 0, 0, 3),
(227, 219, 4, 0, 0, 0, 0, 3),
(228, 220, 1, 0, 0, 0, 0, 3),
(229, 221, 1, 0, 0, 0, 0, 3),
(230, 222, 6, 0, 0, 0, 0, 3),
(231, 223, 3, 0, 0, 0, 0, 3),
(232, 224, 4, 0, 0, 0, 0, 3),
(233, 225, 3, 0, 0, 0, 0, 3),
(234, 226, 1, 0, 0, 0, 0, 3),
(235, 227, 2, 0, 0, 0, 0, 3),
(236, 228, 1, 0, 0, 0, 0, 3),
(237, 229, 2, 0, 0, 0, 0, 3),
(238, 230, 2, 0, 0, 0, 0, 3),
(239, 231, 1, 0, 0, 0, 0, 3),
(240, 232, 1, 0, 0, 0, 0, 3),
(241, 233, 2, 0, 0, 0, 0, 3),
(242, 234, 1, 0, 0, 0, 0, 3),
(243, 235, 1, 0, 0, 0, 0, 3),
(244, 236, 5, 0, 0, 0, 0, 3),
(245, 237, 2, 0, 0, 0, 0, 3),
(246, 28, 2, 0, 0, 0, 0, 3),
(247, 238, 3, 0, 0, 0, 0, 3),
(248, 239, 3, 0, 0, 0, 0, 3),
(249, 240, 1, 0, 0, 0, 0, 3),
(250, 241, 1, 0, 0, 0, 0, 3),
(251, 242, 1, 0, 0, 0, 0, 3),
(252, 243, 1, 0, 0, 0, 0, 3),
(253, 244, 1, 0, 0, 0, 0, 3),
(254, 245, 1, 0, 0, 0, 0, 3),
(255, 14, 6, 0, 0, 0, 0, 3),
(256, 246, 2, 0, 0, 0, 0, 3),
(257, 247, 1, 0, 0, 0, 0, 3),
(258, 248, 1, 0, 0, 0, 0, 3),
(259, 249, 1, 0, 0, 0, 0, 3),
(260, 250, 1, 0, 0, 0, 0, 3),
(261, 251, 1, 0, 0, 0, 0, 3),
(262, 252, 1, 0, 0, 0, 0, 3),
(263, 253, 4, 0, 0, 0, 0, 3),
(264, 254, 1, 0, 0, 0, 0, 3),
(265, 255, 1, 0, 0, 0, 0, 3),
(266, 256, 6, 0, 0, 0, 0, 3),
(267, 257, 2, 0, 0, 0, 0, 3),
(268, 258, 1, 0, 0, 0, 0, 3),
(269, 259, 1, 0, 0, 0, 0, 3),
(270, 260, 1, 0, 0, 0, 0, 3),
(271, 261, 6, 0, 0, 0, 0, 3),
(272, 262, 1, 0, 0, 0, 0, 3),
(273, 263, 1, 0, 0, 0, 0, 3),
(274, 34, 2, 0, 0, 0, 0, 3),
(275, 264, 1, 0, 0, 0, 0, 3),
(276, 265, 9, 0, 0, 0, 0, 3),
(277, 266, 1, 0, 0, 0, 0, 3),
(278, 267, 1, 0, 0, 0, 0, 3),
(279, 268, 1, 0, 0, 0, 0, 3),
(280, 269, 1, 0, 0, 0, 0, 3),
(281, 270, 1, 0, 0, 0, 0, 3),
(282, 271, 1, 0, 0, 0, 0, 3),
(283, 272, 1, 0, 0, 0, 0, 3),
(284, 273, 6, 0, 0, 0, 0, 3),
(285, 274, 3, 0, 0, 0, 0, 3),
(286, 275, 1, 0, 0, 0, 0, 3),
(287, 276, 2, 0, 0, 0, 0, 3),
(288, 22, 1, 0, 0, 0, 0, 3),
(289, 277, 5, 0, 0, 0, 0, 3) ;
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(290, 197, 1, 0, 0, 0, 0, 3),
(291, 278, 2, 0, 0, 0, 0, 3),
(292, 279, 1, 0, 0, 0, 0, 3),
(293, 280, 4, 0, 0, 0, 0, 3),
(294, 281, 1, 0, 0, 0, 0, 3),
(295, 282, 1, 0, 0, 0, 0, 3),
(296, 283, 1, 0, 0, 0, 0, 3),
(297, 284, 1, 0, 0, 0, 0, 3),
(298, 285, 1, 0, 0, 0, 0, 3),
(299, 286, 2, 0, 0, 0, 0, 3),
(300, 287, 1, 0, 0, 0, 0, 3),
(301, 288, 1, 0, 0, 0, 0, 3),
(302, 289, 6, 0, 0, 0, 0, 3),
(303, 23, 2, 0, 0, 0, 0, 3),
(304, 290, 1, 0, 0, 0, 0, 3),
(305, 291, 1, 0, 0, 0, 0, 3),
(306, 292, 2, 0, 0, 0, 0, 3),
(307, 293, 1, 0, 0, 0, 0, 3),
(308, 294, 1, 0, 0, 0, 0, 3),
(309, 295, 1, 0, 0, 0, 0, 3),
(310, 296, 1, 0, 0, 0, 0, 3),
(311, 297, 1, 0, 0, 0, 0, 3),
(312, 298, 1, 0, 0, 0, 0, 3),
(313, 299, 3, 0, 0, 0, 0, 3),
(314, 300, 1, 0, 0, 0, 0, 3),
(315, 7, 3, 0, 0, 0, 0, 3),
(316, 301, 1, 0, 0, 0, 0, 3),
(317, 302, 2, 0, 0, 0, 0, 3),
(318, 303, 3, 0, 0, 0, 0, 3),
(319, 304, 1, 0, 0, 0, 0, 3),
(320, 305, 1, 0, 0, 0, 0, 3),
(321, 306, 1, 0, 0, 0, 0, 3),
(322, 307, 1, 0, 0, 0, 0, 3),
(323, 6, 1, 0, 0, 0, 0, 3),
(324, 308, 1, 0, 0, 0, 0, 3),
(325, 309, 1, 0, 0, 0, 0, 3),
(326, 310, 1, 0, 0, 0, 0, 3),
(327, 311, 1, 0, 0, 0, 0, 3),
(328, 107, 5, 0, 0, 0, 0, 3),
(329, 312, 3, 0, 0, 0, 0, 3),
(330, 313, 2, 0, 0, 0, 0, 3),
(331, 314, 2, 0, 0, 0, 0, 3),
(332, 315, 1, 0, 0, 0, 0, 3),
(333, 316, 1, 0, 0, 0, 0, 3),
(334, 317, 1, 0, 0, 0, 0, 3),
(335, 318, 1, 0, 0, 0, 0, 3),
(336, 319, 1, 0, 0, 0, 0, 3),
(337, 320, 1, 0, 0, 0, 0, 3),
(338, 321, 1, 0, 0, 0, 0, 3),
(339, 322, 1, 0, 0, 0, 0, 3),
(340, 323, 2, 0, 0, 0, 0, 3),
(341, 324, 1, 0, 0, 0, 0, 3),
(342, 325, 2, 0, 0, 0, 0, 3),
(343, 326, 1, 0, 0, 0, 0, 3),
(344, 327, 2, 0, 0, 0, 0, 3),
(345, 328, 2, 0, 0, 0, 0, 3),
(346, 329, 1, 0, 0, 0, 0, 3),
(347, 330, 1, 0, 0, 0, 0, 3),
(348, 331, 1, 0, 0, 0, 0, 3),
(349, 332, 1, 0, 0, 0, 0, 3),
(350, 333, 1, 0, 0, 0, 0, 3),
(351, 334, 1, 0, 0, 0, 0, 3),
(352, 335, 1, 0, 0, 0, 0, 3),
(353, 336, 1, 0, 0, 0, 0, 3),
(354, 337, 1, 0, 0, 0, 0, 3),
(355, 338, 1, 0, 0, 0, 0, 3),
(356, 339, 1, 0, 0, 0, 0, 3),
(357, 340, 1, 0, 0, 0, 0, 3),
(358, 341, 1, 0, 0, 0, 0, 3),
(359, 342, 1, 0, 0, 0, 0, 3),
(360, 343, 1, 0, 0, 0, 0, 3),
(361, 344, 1, 0, 0, 0, 0, 3),
(362, 345, 2, 0, 0, 0, 0, 3),
(363, 346, 1, 0, 0, 0, 0, 3),
(364, 347, 1, 0, 0, 0, 0, 3),
(365, 348, 1, 0, 0, 0, 0, 3),
(366, 8, 1, 0, 0, 0, 0, 3),
(367, 349, 1, 0, 0, 0, 0, 3),
(368, 350, 1, 0, 0, 0, 0, 3),
(369, 351, 1, 0, 0, 0, 0, 3),
(370, 352, 1, 0, 0, 0, 0, 3),
(371, 353, 1, 0, 0, 0, 0, 3),
(372, 354, 1, 0, 0, 0, 0, 3),
(373, 355, 1, 0, 0, 0, 0, 3),
(374, 356, 2, 0, 0, 0, 0, 3),
(375, 357, 2, 0, 0, 0, 0, 3),
(376, 358, 1, 0, 0, 0, 0, 3),
(377, 359, 1, 0, 0, 0, 0, 3),
(378, 360, 2, 0, 0, 0, 0, 3),
(379, 361, 1, 0, 0, 0, 0, 3),
(380, 362, 1, 0, 0, 0, 0, 3),
(381, 363, 1, 0, 0, 0, 0, 3),
(382, 364, 1, 0, 0, 0, 0, 3),
(383, 365, 1, 0, 0, 0, 0, 3),
(384, 366, 1, 0, 0, 0, 0, 3),
(385, 367, 1, 0, 0, 0, 0, 3),
(386, 368, 1, 0, 0, 0, 0, 3),
(387, 369, 1, 0, 0, 0, 0, 3),
(388, 370, 2, 0, 0, 0, 0, 3),
(389, 371, 1, 0, 0, 0, 0, 3) ;
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(390, 372, 1, 0, 0, 0, 0, 3),
(391, 373, 1, 0, 0, 0, 0, 3),
(392, 374, 1, 0, 0, 0, 0, 3),
(393, 375, 1, 0, 0, 0, 0, 3),
(394, 376, 1, 0, 0, 0, 0, 3),
(395, 377, 1, 0, 0, 0, 0, 3),
(396, 378, 1, 0, 0, 0, 0, 3),
(397, 379, 1, 0, 0, 0, 0, 3),
(398, 380, 1, 0, 0, 0, 0, 3),
(399, 381, 1, 0, 0, 0, 0, 3),
(400, 382, 1, 0, 0, 0, 0, 3),
(401, 383, 1, 0, 0, 0, 0, 3),
(402, 384, 1, 0, 0, 0, 0, 3),
(403, 385, 1, 0, 0, 0, 0, 3),
(404, 11, 1, 0, 0, 0, 0, 3),
(405, 208, 1, 0, 0, 0, 0, 3),
(406, 13, 1, 0, 0, 0, 0, 3),
(407, 12, 1, 0, 0, 0, 0, 3),
(408, 386, 1, 0, 0, 0, 0, 3),
(409, 387, 1, 0, 0, 0, 0, 3),
(410, 388, 1, 0, 0, 0, 0, 3),
(411, 36, 0, 1, 0, 0, 1, 17),
(412, 37, 1, 0, 0, 0, 0, 17),
(413, 38, 3, 0, 0, 0, 0, 17),
(414, 39, 2, 0, 0, 0, 0, 17),
(415, 40, 3, 0, 0, 0, 0, 17),
(416, 41, 3, 0, 0, 0, 0, 17),
(417, 42, 1, 0, 0, 0, 0, 17),
(418, 43, 1, 0, 0, 0, 0, 17),
(419, 44, 1, 0, 0, 0, 0, 17),
(420, 45, 2, 0, 0, 0, 0, 17),
(421, 46, 1, 0, 0, 0, 0, 17),
(422, 47, 1, 0, 0, 0, 0, 17),
(423, 48, 2, 0, 0, 0, 0, 17),
(424, 49, 1, 0, 0, 0, 0, 17),
(425, 50, 2, 0, 0, 0, 0, 17),
(426, 51, 1, 0, 0, 0, 0, 17),
(427, 52, 2, 0, 0, 0, 0, 17),
(428, 53, 1, 0, 0, 0, 0, 17),
(429, 54, 1, 0, 0, 0, 0, 17),
(430, 55, 3, 0, 0, 0, 0, 17),
(431, 56, 1, 0, 0, 0, 0, 17),
(432, 57, 1, 0, 0, 0, 0, 17),
(433, 58, 1, 0, 0, 0, 0, 17),
(434, 59, 1, 0, 0, 0, 0, 17),
(435, 60, 1, 0, 0, 0, 0, 17),
(436, 61, 1, 0, 0, 0, 0, 17),
(437, 62, 2, 0, 0, 0, 0, 17),
(438, 63, 2, 0, 0, 0, 0, 17),
(439, 64, 3, 0, 0, 0, 0, 17),
(440, 65, 1, 0, 0, 0, 0, 17),
(441, 66, 1, 0, 0, 0, 0, 17),
(442, 67, 1, 0, 0, 0, 0, 17),
(443, 68, 1, 0, 0, 0, 0, 17),
(444, 69, 1, 0, 0, 0, 0, 17),
(445, 70, 2, 0, 0, 0, 0, 17),
(446, 71, 1, 0, 0, 0, 0, 17),
(447, 72, 1, 0, 0, 0, 0, 17),
(448, 73, 1, 0, 0, 0, 0, 17),
(449, 74, 1, 0, 0, 0, 0, 17),
(450, 75, 1, 0, 0, 0, 0, 17),
(451, 76, 1, 0, 0, 0, 0, 17),
(452, 77, 1, 0, 0, 0, 0, 17),
(453, 78, 1, 0, 0, 0, 0, 17),
(454, 79, 1, 0, 0, 0, 0, 17),
(455, 80, 1, 0, 0, 0, 0, 17),
(456, 81, 1, 0, 0, 0, 0, 17),
(457, 82, 1, 0, 0, 0, 0, 17),
(458, 83, 1, 0, 0, 0, 0, 17),
(459, 84, 2, 0, 0, 0, 0, 17),
(460, 85, 1, 0, 0, 0, 0, 17),
(461, 86, 1, 0, 0, 0, 0, 17),
(462, 87, 1, 0, 0, 0, 0, 17),
(463, 88, 1, 0, 0, 0, 0, 17),
(464, 89, 1, 0, 0, 0, 0, 17),
(465, 90, 2, 0, 0, 0, 0, 17),
(466, 91, 1, 0, 0, 0, 0, 17),
(467, 92, 1, 0, 0, 0, 0, 17),
(468, 93, 1, 0, 0, 0, 0, 17),
(469, 94, 1, 0, 0, 0, 0, 17),
(470, 95, 1, 0, 0, 0, 0, 17),
(471, 96, 1, 0, 0, 0, 0, 17),
(472, 97, 1, 0, 0, 0, 0, 17),
(473, 98, 1, 0, 0, 0, 0, 17),
(474, 99, 1, 0, 0, 0, 0, 17),
(475, 100, 1, 0, 0, 0, 0, 17),
(476, 101, 1, 0, 0, 0, 0, 17),
(477, 102, 1, 0, 0, 0, 0, 17),
(478, 103, 1, 0, 0, 0, 0, 17),
(479, 104, 1, 0, 0, 0, 0, 17),
(480, 105, 1, 0, 0, 0, 0, 17),
(481, 106, 1, 0, 0, 0, 0, 17),
(482, 107, 1, 0, 0, 0, 0, 17),
(483, 108, 1, 0, 0, 0, 0, 17),
(484, 109, 1, 0, 0, 0, 0, 17),
(485, 110, 1, 0, 0, 0, 0, 17),
(486, 111, 1, 0, 0, 0, 0, 17),
(487, 11, 1, 0, 0, 0, 0, 17),
(488, 112, 1, 0, 0, 0, 0, 17),
(489, 13, 1, 0, 0, 0, 0, 17) ;
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(490, 113, 1, 0, 0, 0, 0, 17),
(491, 114, 1, 0, 0, 0, 0, 17),
(492, 116, 1, 0, 0, 0, 0, 17),
(493, 117, 1, 0, 0, 0, 0, 17),
(494, 118, 1, 0, 0, 0, 0, 17),
(495, 119, 1, 0, 0, 0, 0, 17),
(496, 12, 1, 0, 0, 0, 0, 17),
(497, 120, 1, 0, 0, 0, 0, 17),
(498, 121, 1, 0, 0, 0, 0, 17) ;

#
# End of data contents of table `wp_swp_index`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_log`
#

DROP TABLE IF EXISTS `wp_swp_log`;


#
# Table structure of table `wp_swp_log`
#

CREATE TABLE `wp_swp_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event` enum('search','action') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'search',
  `query` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `hits` mediumint(9) unsigned NOT NULL,
  `engine` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `wpsearch` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `eventindex` (`event`),
  KEY `queryindex` (`query`),
  KEY `engineindex` (`engine`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_log`
#
INSERT INTO `wp_swp_log` ( `id`, `event`, `query`, `tstamp`, `hits`, `engine`, `wpsearch`) VALUES
(1, 'search', 'login', '2020-03-24 11:01:58', 0, 'default', 0),
(2, 'search', 'login', '2020-03-24 11:26:50', 0, 'default', 0),
(3, 'search', 'login', '2020-03-24 11:26:57', 0, 'default', 0),
(4, 'search', 'login', '2020-03-24 11:27:18', 0, 'default', 0),
(5, 'search', 'login', '2020-03-24 11:27:19', 0, 'default', 0),
(6, 'search', 'login', '2020-03-24 11:27:33', 0, 'default', 0),
(7, 'search', 'login', '2020-03-24 11:27:43', 0, 'default', 0),
(8, 'search', 'login', '2020-03-24 11:28:00', 0, 'default', 0),
(9, 'search', 'login', '2020-03-24 11:28:06', 0, 'default', 0),
(10, 'search', 'login', '2020-03-24 11:28:23', 0, 'default', 0),
(11, 'search', 'login', '2020-03-24 11:29:27', 0, 'default', 0),
(12, 'search', 'login', '2020-03-24 11:29:42', 0, 'default', 0),
(13, 'search', 'login', '2020-03-24 11:32:01', 0, 'default', 0),
(14, 'search', 'login', '2020-03-24 11:33:31', 0, 'default', 0),
(15, 'search', 'login', '2020-03-24 11:33:32', 0, 'default', 0),
(16, 'search', 'login', '2020-03-24 11:33:44', 0, 'default', 0),
(17, 'search', 'login', '2020-03-24 11:36:06', 0, 'default', 0),
(18, 'search', 'login', '2020-03-24 11:36:07', 0, 'default', 0),
(19, 'search', 'login', '2020-03-24 11:36:48', 0, 'default', 0),
(20, 'search', 'login', '2020-03-24 11:36:50', 0, 'default', 0),
(21, 'search', 'login', '2020-03-24 11:36:56', 0, 'default', 0),
(22, 'search', 'login', '2020-03-24 11:37:54', 0, 'default', 0),
(23, 'search', 'login', '2020-03-24 11:37:55', 0, 'default', 0),
(24, 'search', 'login', '2020-03-24 11:38:23', 0, 'default', 0),
(25, 'search', 'login', '2020-03-24 11:38:24', 0, 'default', 0),
(26, 'search', 'login', '2020-03-24 11:38:30', 0, 'default', 0),
(27, 'search', 'login', '2020-03-24 11:38:31', 0, 'default', 0),
(28, 'search', 'login', '2020-03-24 11:38:47', 0, 'default', 0),
(29, 'search', 'login', '2020-03-24 11:38:49', 0, 'default', 0),
(30, 'search', 'login', '2020-03-24 11:39:55', 0, 'default', 0),
(31, 'search', 'login', '2020-03-24 11:40:18', 0, 'default', 0),
(32, 'search', 'sdf a', '2020-03-24 12:47:22', 0, 'default', 0),
(33, 'search', 'sdf a', '2020-03-24 12:48:12', 0, 'default', 0),
(34, 'search', 'sdf a', '2020-03-24 12:48:13', 0, 'default', 0),
(35, 'search', 'sdf a', '2020-03-24 12:48:16', 0, 'default', 0),
(36, 'search', 'sdf a', '2020-03-24 12:48:31', 0, 'default', 0),
(37, 'search', 'sdf a', '2020-03-24 12:48:33', 0, 'default', 0),
(38, 'search', 'sdf a', '2020-03-24 12:48:35', 0, 'default', 0),
(39, 'search', 'sdf a', '2020-03-24 12:48:39', 0, 'default', 0),
(40, 'search', 'sdf a', '2020-03-24 12:49:09', 0, 'default', 0),
(41, 'search', 'sdf a', '2020-03-24 12:49:34', 0, 'default', 0),
(42, 'search', 'sdf a', '2020-03-24 12:49:36', 0, 'default', 0),
(43, 'search', 'sdf a', '2020-03-24 12:49:38', 0, 'default', 0),
(44, 'search', 'sdf a', '2020-03-24 12:49:56', 0, 'default', 0),
(45, 'search', 'sdf a', '2020-03-24 12:49:58', 0, 'default', 0),
(46, 'search', 'sdf a', '2020-03-24 12:50:00', 0, 'default', 0),
(47, 'search', 'sdf a', '2020-03-24 12:51:03', 0, 'default', 0),
(48, 'search', 'sdf a', '2020-03-24 12:51:05', 0, 'default', 0),
(49, 'search', 'sdf a', '2020-03-24 12:52:10', 0, 'default', 0),
(50, 'search', 'sdf a', '2020-03-24 12:52:13', 0, 'default', 0),
(51, 'search', 'sdf a', '2020-03-24 12:52:30', 0, 'default', 0),
(52, 'search', 'sdf a', '2020-03-24 12:52:32', 0, 'default', 0),
(53, 'search', 'sdf a', '2020-03-24 12:55:12', 0, 'default', 0),
(54, 'search', 'test', '2020-03-24 12:55:38', 0, 'default', 0),
(55, 'search', 'test', '2020-03-24 12:55:50', 0, 'default', 0),
(56, 'search', 'test', '2020-03-24 13:48:05', 0, 'default', 0),
(57, 'search', 'test', '2020-03-24 13:48:13', 0, 'default', 0),
(58, 'search', 'test', '2020-03-24 13:48:25', 0, 'default', 0),
(59, 'search', 'test', '2020-03-24 13:49:03', 0, 'default', 0),
(60, 'search', 'test', '2020-03-24 13:54:24', 0, 'default', 0),
(61, 'search', 'test', '2020-03-24 13:54:32', 0, 'default', 0),
(62, 'search', 'test', '2020-03-24 13:54:50', 0, 'default', 0),
(63, 'search', 'test', '2020-03-24 13:54:51', 0, 'default', 0),
(64, 'search', 'test', '2020-03-24 13:54:59', 0, 'default', 0),
(65, 'search', 'test', '2020-03-24 13:55:07', 0, 'default', 0),
(66, 'search', 'test', '2020-03-24 13:55:10', 0, 'default', 0),
(67, 'search', 'test', '2020-03-24 13:55:24', 0, 'default', 0),
(68, 'search', 'test', '2020-03-24 13:55:30', 0, 'default', 0),
(69, 'search', 'test', '2020-03-24 13:55:41', 0, 'default', 0),
(70, 'search', 'test', '2020-03-24 13:56:57', 0, 'default', 0),
(71, 'search', 'test', '2020-03-24 13:57:30', 0, 'default', 0),
(72, 'search', 'test', '2020-03-24 13:57:35', 0, 'default', 0),
(73, 'search', 'lorem', '2020-03-24 14:03:05', 2, 'default', 0),
(74, 'search', 'lorem', '2020-03-24 14:08:50', 2, 'default', 0),
(75, 'search', 'lorem', '2020-03-24 14:09:10', 2, 'default', 0),
(76, 'search', 'lorem', '2020-03-24 14:09:32', 2, 'default', 0),
(77, 'search', 'lorem', '2020-03-24 14:09:50', 2, 'default', 0),
(78, 'search', 'lorem', '2020-03-24 14:09:57', 2, 'default', 0),
(79, 'search', 'lorem', '2020-03-24 14:10:24', 2, 'default', 0),
(80, 'search', 'lorem', '2020-03-24 14:10:26', 2, 'default', 0),
(81, 'search', 'lorem', '2020-03-24 14:10:29', 2, 'default', 0),
(82, 'search', 'lorem', '2020-03-24 14:10:50', 2, 'default', 0),
(83, 'search', 'lorem', '2020-03-24 14:11:20', 2, 'default', 0),
(84, 'search', 'lorem', '2020-03-24 14:11:47', 2, 'default', 0),
(85, 'search', 'lorem', '2020-03-24 14:12:26', 2, 'default', 0),
(86, 'search', 'lorem', '2020-03-24 14:12:28', 2, 'default', 0),
(87, 'search', 'lorem', '2020-03-24 14:12:57', 2, 'default', 0),
(88, 'search', 'lorem', '2020-03-24 14:12:58', 2, 'default', 0),
(89, 'search', 'lorem', '2020-03-24 14:13:48', 2, 'default', 0),
(90, 'search', 'lorem', '2020-03-24 14:13:49', 2, 'default', 0),
(91, 'search', 'lorem', '2020-03-24 14:15:01', 2, 'default', 0),
(92, 'search', 'lorem', '2020-03-24 14:15:02', 2, 'default', 0),
(93, 'search', 'lorem', '2020-03-24 14:15:21', 2, 'default', 0),
(94, 'search', 'lorem', '2020-03-24 14:15:26', 2, 'default', 0),
(95, 'search', 'lorem', '2020-03-24 14:15:27', 2, 'default', 0),
(96, 'search', 'lorem', '2020-03-24 14:15:28', 2, 'default', 0),
(97, 'search', 'lorem', '2020-03-24 14:15:30', 2, 'default', 0),
(98, 'search', 'lorem', '2020-03-24 14:15:35', 2, 'default', 0),
(99, 'search', 'lorem', '2020-03-24 14:15:36', 2, 'default', 0),
(100, 'search', 'lorem', '2020-03-24 14:15:43', 2, 'default', 0) ;
INSERT INTO `wp_swp_log` ( `id`, `event`, `query`, `tstamp`, `hits`, `engine`, `wpsearch`) VALUES
(101, 'search', 'lorem', '2020-03-24 14:15:44', 2, 'default', 0),
(102, 'search', 'lorem', '2020-03-24 14:15:48', 2, 'default', 0),
(103, 'search', 'lorem', '2020-03-24 14:15:51', 2, 'default', 0),
(104, 'search', 'lorem', '2020-03-24 14:15:52', 2, 'default', 0),
(105, 'search', 'lorem', '2020-03-24 14:15:53', 2, 'default', 0),
(106, 'search', 'lorem', '2020-03-24 14:16:10', 2, 'default', 0) ;

#
# End of data contents of table `wp_swp_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_tax`
#

DROP TABLE IF EXISTS `wp_swp_tax`;


#
# Table structure of table `wp_swp_tax`
#

CREATE TABLE `wp_swp_tax` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` int(20) unsigned NOT NULL,
  `count` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taxonomy` (`taxonomy`),
  KEY `term` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_tax`
#

#
# End of data contents of table `wp_swp_tax`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_terms`
#

DROP TABLE IF EXISTS `wp_swp_terms`;


#
# Table structure of table `wp_swp_terms`
#

CREATE TABLE `wp_swp_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `reverse` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `stem` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `termunique` (`term`),
  KEY `termindex` (`term`(2)),
  KEY `stemindex` (`stem`(2))
) ENGINE=InnoDB AUTO_INCREMENT=515 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


#
# Data contents of table `wp_swp_terms`
#
INSERT INTO `wp_swp_terms` ( `id`, `term`, `reverse`, `stem`) VALUES
(1, 'hello', 'olleh', 'hello'),
(2, 'world', 'dlrow', 'world'),
(3, 'welcome', 'emoclew', 'welcom'),
(4, 'wordpress', 'sserpdrow', 'wordpress'),
(5, 'first', 'tsrif', 'first'),
(6, 'post', 'tsop', 'post'),
(7, 'edit', 'tide', 'edit'),
(8, 'delete', 'eteled', 'delet'),
(9, 'start', 'trats', 'start'),
(10, 'writing', 'gnitirw', 'write'),
(11, 'gutenberg-section', 'noitces-grebnetug', 'gutenberg-sect'),
(12, 'core-paragraph', 'hpargarap-eroc', 'core-paragraph'),
(13, 'gutenberg-container', 'reniatnoc-grebnetug', 'gutenberg-contain'),
(14, 'comment', 'tnemmoc', 'comment'),
(15, 'get', 'teg', 'get'),
(16, 'started', 'detrats', 'start'),
(17, 'moderating', 'gnitaredom', 'moder'),
(18, 'editing', 'gnitide', 'edit'),
(19, 'deleting', 'gniteled', 'delet'),
(20, 'comments', 'stnemmoc', 'comment'),
(21, 'please', 'esaelp', 'pleas'),
(22, 'visit', 'tisiv', 'visit'),
(23, 'screen', 'neercs', 'screen'),
(24, 'dashboard', 'draobhsad', 'dashboard'),
(25, 'commenter', 'retnemmoc', 'comment'),
(26, 'avatars', 'sratava', 'avatar'),
(27, 'come', 'emoc', 'come'),
(28, 'gravatar', 'ratavarg', 'gravatar'),
(29, 'gravatar.com', 'moc.ratavarg', 'gravatar.com'),
(30, 'marketing', 'gnitekram', 'market'),
(31, 'materials', 'slairetam', 'materi'),
(32, 'event', 'tneve', 'event'),
(33, 'planning', 'gninnalp', 'plan'),
(34, 'contact', 'tcatnoc', 'contact'),
(35, 'blog', 'golb', 'blog'),
(36, 'services', 'secivres', 'servic'),
(37, 'lorem', 'merol', 'lorem'),
(38, 'ipsum', 'muspi', 'ipsum'),
(39, 'dolor', 'rolod', 'dolor'),
(40, 'sit', 'tis', 'sit'),
(41, 'amet', 'tema', 'amet'),
(42, 'consectetur', 'rutetcesnoc', 'consectetur'),
(43, 'adipiscing', 'gnicsipida', 'adipisc'),
(44, 'elit', 'tile', 'elit'),
(45, 'cras', 'sarc', 'cras'),
(46, 'vitae', 'eativ', 'vita'),
(47, 'purus', 'surup', 'purus'),
(48, 'mauris', 'siruam', 'mauri'),
(49, 'iaculis', 'silucai', 'iaculi'),
(50, 'bibendum', 'mudnebib', 'bibendum'),
(51, 'justo', 'otsuj', 'justo'),
(52, 'aliquam', 'mauqila', 'aliquam'),
(53, 'pretium', 'muiterp', 'pretium'),
(54, 'dui', 'iud', 'dui'),
(55, 'sed', 'des', 'sed'),
(56, 'odio', 'oido', 'odio'),
(57, 'facilisis', 'sisilicaf', 'facilisi'),
(58, 'ultricies', 'seicirtlu', 'ultrici'),
(59, 'gravida', 'adivarg', 'gravida'),
(60, 'convallis', 'sillavnoc', 'conval'),
(61, 'leo', 'oel', 'leo'),
(62, 'egestas', 'satsege', 'egesta'),
(63, 'quis', 'siuq', 'qui'),
(64, 'orci', 'icro', 'orci'),
(65, 'turpis', 'siprut', 'turpi'),
(66, 'dictum', 'mutcid', 'dictum'),
(67, 'posuere', 'ereusop', 'posuer'),
(68, 'erat', 'tare', 'erat'),
(69, 'venenatis', 'sitanenev', 'venenati'),
(70, 'placerat', 'tarecalp', 'placerat'),
(71, 'praesent', 'tnesearp', 'praesent'),
(72, 'magna', 'angam', 'magna'),
(73, 'nisl', 'lsin', 'nisl'),
(74, 'commodo', 'odommoc', 'commodo'),
(75, 'nec', 'cen', 'nec'),
(76, 'lacinia', 'ainical', 'lacinia'),
(77, 'interdum', 'mudretni', 'interdum'),
(78, 'class', 'ssalc', 'class'),
(79, 'aptent', 'tnetpa', 'aptent'),
(80, 'taciti', 'iticat', 'taciti'),
(81, 'sociosqu', 'uqsoicos', 'sociosqu'),
(82, 'litora', 'arotil', 'litora'),
(83, 'torquent', 'tneuqrot', 'torquent'),
(84, 'per', 'rep', 'per'),
(85, 'conubia', 'aibunoc', 'conubia'),
(86, 'nostra', 'artson', 'nostra'),
(87, 'inceptos', 'sotpecni', 'incepto'),
(88, 'himenaeos', 'soeanemih', 'himenaeo'),
(89, 'proin', 'niorp', 'proin'),
(90, 'laoreet', 'teeroal', 'laoreet'),
(91, 'non', 'non', 'non'),
(92, 'suspendisse', 'essidnepsus', 'suspendiss'),
(93, 'neque', 'euqen', 'nequ'),
(94, 'mollis', 'sillom', 'molli'),
(95, 'sem', 'mes', 'sem'),
(96, 'dignissim', 'missingid', 'dignissim'),
(97, 'lectus', 'sutcel', 'lectus'),
(98, 'ullamcorper', 'reprocmallu', 'ullamcorp'),
(99, 'est', 'tse', 'est'),
(100, 'eget', 'tege', 'eget') ;
INSERT INTO `wp_swp_terms` ( `id`, `term`, `reverse`, `stem`) VALUES
(101, 'nulla', 'allun', 'nulla'),
(102, 'ornare', 'eranro', 'ornar'),
(103, 'mattis', 'sittam', 'matti'),
(104, 'http', 'ptth', 'http'),
(105, 'localhost', 'tsohlacol', 'localhost'),
(106, 'nousot', 'tosuon', 'nousot'),
(107, 'content', 'tnetnoc', 'content'),
(108, 'uploads', 'sdaolpu', 'upload'),
(109, 'hands', 'sdnah', 'hand'),
(110, 'jpg', 'gpj', 'jpg'),
(111, 'hands.jpg', 'gpj.sdnah', 'hands.jpg'),
(112, 'core-media-text', 'txet-aidem-eroc', 'core-media-text'),
(113, 'wp-block-media-text', 'txet-aidem-kcolb-pw', 'wp-block-media-text'),
(114, 'is-stacked-on-mobile', 'elibom-no-dekcats-si', 'is-stacked-on-mobil'),
(115, 'grid-template-columns', 'snmuloc-etalpmet-dirg', 'grid-template-column'),
(116, 'wp-block-media-text__media', 'aidem__txet-aidem-kcolb-pw', 'wp-block-media-text__media'),
(117, 'wp-content', 'tnetnoc-pw', 'wp-content'),
(118, 'wp-image-18', '81-egami-pw', 'wp-image-18'),
(119, 'wp-block-media-text__content', 'tnetnoc__txet-aidem-kcolb-pw', 'wp-block-media-text__cont'),
(120, 'has-normal-font-size', 'ezis-tnof-lamron-sah', 'has-normal-font-s'),
(121, '2020', '0202', '2020'),
(195, 'home', 'emoh', 'home'),
(196, 'sample', 'elpmas', 'sampl'),
(197, 'page', 'egap', 'page'),
(198, 'learn', 'nrael', 'learn'),
(199, 'url(', '(lru', 'url('),
(200, 'url', 'lru', 'url'),
(201, '3281255.jpg', 'gpj.5521823', '3281255.jpg'),
(202, 'core-cover', 'revoc-eroc', 'core-cov'),
(203, 'wp-block-cover', 'revoc-kcolb-pw', 'wp-block-cov'),
(204, 'has-background-dim', 'mid-dnuorgkcab-sah', 'has-background-dim'),
(205, 'background-image', 'egami-dnuorgkcab', 'background-imag'),
(206, 'fire-planet-3281255', '5521823-tenalp-erif', 'fire-planet-3281255'),
(207, 'wp-block-cover__inner-container', 'reniatnoc-renni__revoc-kcolb-pw', 'wp-block-cover__inner-contain'),
(208, 'core-heading', 'gnidaeh-eroc', 'core-head'),
(209, '3281255', '5521823', '3281255'),
(210, 'privacy', 'ycavirp', 'privaci'),
(211, 'policy', 'ycilop', 'polici'),
(212, 'website', 'etisbew', 'websit'),
(213, 'address', 'sserdda', 'address'),
(214, 'personal', 'lanosrep', 'person'),
(215, 'data', 'atad', 'data'),
(216, 'collect', 'tcelloc', 'collect'),
(217, 'visitors', 'srotisiv', 'visitor'),
(218, 'leave', 'evael', 'leav'),
(219, 'site', 'etis', 'site'),
(220, 'shown', 'nwohs', 'shown'),
(221, 'form', 'mrof', 'form'),
(222, 'also', 'osla', 'also'),
(223, 'visitor', 'rotisiv', 'visitor'),
(224, 'browser', 'resworb', 'browser'),
(225, 'user', 'resu', 'user'),
(226, 'agent', 'tnega', 'agent'),
(227, 'string', 'gnirts', 'string'),
(228, 'help', 'pleh', 'help'),
(229, 'spam', 'maps', 'spam'),
(230, 'detection', 'noitceted', 'detect'),
(231, 'anonymized', 'dezimynona', 'anonym'),
(232, 'created', 'detaerc', 'creat'),
(233, 'email', 'liame', 'email'),
(234, 'called', 'dellac', 'call'),
(235, 'hash', 'hsah', 'hash'),
(236, 'may', 'yam', 'may'),
(237, 'provided', 'dedivorp', 'provid'),
(238, 'service', 'ecivres', 'servic'),
(239, 'see', 'ees', 'see'),
(240, 'using', 'gnisu', 'use'),
(241, 'available', 'elbaliava', 'avail'),
(242, 'https', 'sptth', 'https'),
(243, 'automattic', 'cittamotua', 'automatt'),
(244, 'com', 'moc', 'com'),
(245, 'approval', 'lavorppa', 'approv'),
(246, 'profile', 'eliforp', 'profil'),
(247, 'picture', 'erutcip', 'pictur'),
(248, 'visible', 'elbisiv', 'visibl'),
(249, 'public', 'cilbup', 'public'),
(250, 'context', 'txetnoc', 'context'),
(251, 'media', 'aidem', 'media'),
(252, 'upload', 'daolpu', 'upload'),
(253, 'images', 'segami', 'imag'),
(254, 'avoid', 'diova', 'avoid'),
(255, 'uploading', 'gnidaolpu', 'upload'),
(256, 'embedded', 'deddebme', 'embed'),
(257, 'location', 'noitacol', 'locat'),
(258, 'exif', 'fixe', 'exif'),
(259, 'gps', 'spg', 'gps'),
(260, 'included', 'dedulcni', 'includ'),
(261, 'can', 'nac', 'can'),
(262, 'download', 'daolnwod', 'download'),
(263, 'extract', 'tcartxe', 'extract'),
(264, 'forms', 'smrof', 'form'),
(265, 'cookies', 'seikooc', 'cooki'),
(266, 'opt', 'tpo', 'opt'),
(267, 'saving', 'gnivas', 'save'),
(268, 'name', 'eman', 'name'),
(269, 'convenience', 'ecneinevnoc', 'conveni'),
(270, 'fill', 'llif', 'fill'),
(271, 'details', 'sliated', 'detail'),
(272, 'another', 'rehtona', 'anoth'),
(273, 'will', 'lliw', 'will') ;
INSERT INTO `wp_swp_terms` ( `id`, `term`, `reverse`, `stem`) VALUES
(274, 'last', 'tsal', 'last'),
(275, 'one', 'eno', 'one'),
(276, 'year', 'raey', 'year'),
(277, 'login', 'nigol', 'login'),
(278, 'set', 'tes', 'set'),
(279, 'temporary', 'yraropmet', 'temporari'),
(280, 'cookie', 'eikooc', 'cooki'),
(281, 'determine', 'enimreted', 'determin'),
(282, 'accepts', 'stpecca', 'accept'),
(283, 'contains', 'sniatnoc', 'contain'),
(284, 'discarded', 'dedracsid', 'discard'),
(285, 'close', 'esolc', 'close'),
(286, 'log', 'gol', 'log'),
(287, 'several', 'lareves', 'sever'),
(288, 'save', 'evas', 'save'),
(289, 'information', 'noitamrofni', 'inform'),
(290, 'display', 'yalpsid', 'display'),
(291, 'choices', 'seciohc', 'choic'),
(292, 'two', 'owt', 'two'),
(293, 'days', 'syad', 'day'),
(294, 'options', 'snoitpo', 'option'),
(295, 'select', 'tceles', 'select'),
(296, 'remember', 'rebmemer', 'rememb'),
(297, 'persist', 'tsisrep', 'persist'),
(298, 'weeks', 'skeew', 'week'),
(299, 'account', 'tnuocca', 'account'),
(300, 'removed', 'devomer', 'remov'),
(301, 'publish', 'hsilbup', 'publish'),
(302, 'article', 'elcitra', 'articl'),
(303, 'additional', 'lanoitidda', 'addit'),
(304, 'saved', 'devas', 'save'),
(305, 'includes', 'sedulcni', 'includ'),
(306, 'simply', 'ylpmis', 'simpli'),
(307, 'indicates', 'setacidni', 'indic'),
(308, 'just', 'tsuj', 'just'),
(309, 'edited', 'detide', 'edit'),
(310, 'expires', 'seripxe', 'expir'),
(311, 'day', 'yad', 'day'),
(312, 'websites', 'setisbew', 'websit'),
(313, 'articles', 'selcitra', 'articl'),
(314, 'include', 'edulcni', 'includ'),
(315, 'videos', 'soediv', 'video'),
(316, 'etc', 'cte', 'etc'),
(317, 'behaves', 'sevaheb', 'behav'),
(318, 'exact', 'tcaxe', 'exact'),
(319, 'way', 'yaw', 'way'),
(320, 'visited', 'detisiv', 'visit'),
(321, 'use', 'esu', 'use'),
(322, 'embed', 'debme', 'emb'),
(323, 'third', 'driht', 'third'),
(324, 'party', 'ytrap', 'parti'),
(325, 'tracking', 'gnikcart', 'track'),
(326, 'monitor', 'rotinom', 'monitor'),
(327, 'interaction', 'noitcaretni', 'interact'),
(328, 'including', 'gnidulcni', 'includ'),
(329, 'logged', 'deggol', 'log'),
(330, 'analytics', 'scitylana', 'analyt'),
(331, 'share', 'erahs', 'share'),
(332, 'long', 'gnol', 'long'),
(333, 'retain', 'niater', 'retain'),
(334, 'metadata', 'atadatem', 'metadata'),
(335, 'retained', 'deniater', 'retain'),
(336, 'indefinitely', 'yletinifedni', 'indefinit'),
(337, 'recognize', 'ezingocer', 'recogn'),
(338, 'approve', 'evorppa', 'approv'),
(339, 'follow', 'wollof', 'follow'),
(340, 'automatically', 'yllacitamotua', 'automat'),
(341, 'instead', 'daetsni', 'instead'),
(342, 'holding', 'gnidloh', 'hold'),
(343, 'moderation', 'noitaredom', 'moder'),
(344, 'queue', 'eueuq', 'queue'),
(345, 'users', 'sresu', 'user'),
(346, 'register', 'retsiger', 'regist'),
(347, 'store', 'erots', 'store'),
(348, 'provide', 'edivorp', 'provid'),
(349, 'time', 'emit', 'time'),
(350, 'except', 'tpecxe', 'except'),
(351, 'change', 'egnahc', 'chang'),
(352, 'username', 'emanresu', 'usernam'),
(353, 'administrators', 'srotartsinimda', 'administr'),
(354, 'rights', 'sthgir', 'right'),
(355, 'left', 'tfel', 'left'),
(356, 'request', 'tseuqer', 'request'),
(357, 'receive', 'eviecer', 'receiv'),
(358, 'exported', 'detropxe', 'export'),
(359, 'file', 'elif', 'file'),
(360, 'hold', 'dloh', 'hold'),
(361, 'erase', 'esare', 'eras'),
(362, 'obliged', 'degilbo', 'oblig'),
(363, 'keep', 'peek', 'keep'),
(364, 'administrative', 'evitartsinimda', 'administr'),
(365, 'legal', 'lagel', 'legal'),
(366, 'security', 'ytiruces', 'secur'),
(367, 'purposes', 'sesoprup', 'purpos'),
(368, 'send', 'dnes', 'send'),
(369, 'checked', 'dekcehc', 'check'),
(370, 'automated', 'detamotua', 'autom'),
(371, 'protect', 'tcetorp', 'protect'),
(372, 'breach', 'hcaerb', 'breach'),
(373, 'procedures', 'serudecorp', 'procedur') ;
INSERT INTO `wp_swp_terms` ( `id`, `term`, `reverse`, `stem`) VALUES
(374, 'place', 'ecalp', 'place'),
(375, 'parties', 'seitrap', 'parti'),
(376, 'decision', 'noisiced', 'decis'),
(377, 'making', 'gnikam', 'make'),
(378, 'profiling', 'gniliforp', 'profil'),
(379, 'industry', 'yrtsudni', 'industri'),
(380, 'regulatory', 'yrotaluger', 'regulatori'),
(381, 'disclosure', 'erusolcsid', 'disclosur'),
(382, 'requirements', 'stnemeriuqer', 'requir'),
(383, 'e.g.', '.g.e', 'e.g.'),
(384, 'e.g', 'g.e', 'e.g'),
(385, 'automattic.com', 'moc.cittamotua', 'automattic.com'),
(386, 'opt-in', 'ni-tpo', 'opt-in'),
(387, 'third-party', 'ytrap-driht', 'third-parti'),
(388, 'follow-up', 'pu-wollof', 'follow-up'),
(495, 'kitchen', 'nehctik', 'kitchen'),
(496, 'sink', 'knis', 'sink'),
(497, 'within', 'nihtiw', 'within'),
(498, 'four', 'ruof', 'four'),
(499, 'seas', 'saes', 'sea'),
(500, 'men', 'nem', 'men'),
(501, 'brothers', 'srehtorb', 'brother'),
(502, 'confucius', 'suicufnoc', 'confucius'),
(503, 'image', 'egami', 'imag'),
(504, 'caption', 'noitpac', 'caption'),
(505, 'bold', 'dlob', 'bold'),
(506, 'italic', 'cilati', 'ital'),
(507, 'link', 'knil', 'link'),
(508, 'google.com', 'moc.elgoog', 'google.com'),
(509, 'core-quote', 'etouq-eroc', 'core-quot'),
(510, 'wp-block-quote', 'etouq-kcolb-pw', 'wp-block-quot'),
(511, 'core-image', 'egami-eroc', 'core-imag'),
(512, 'wp-block-image', 'egami-kcolb-pw', 'wp-block-imag'),
(513, 'size-large', 'egral-ezis', 'size-larg'),
(514, 'aria-label', 'lebal-aira', 'aria-label') ;

#
# End of data contents of table `wp_swp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(8, 2, 0),
(9, 2, 0),
(23, 3, 0),
(24, 3, 0),
(25, 3, 0),
(28, 3, 0),
(31, 3, 0),
(36, 3, 0),
(37, 3, 0),
(42, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 3),
(3, 3, 'nav_menu', '', 0, 7) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'social media', 'social-media', 0),
(3, 'main menu', 'main-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'nousot-dev'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"956134f5ea6f084c9ba85013793fa2e2df5836c6251e7df30a9f2bb59696a2cf";a:4:{s:10:"expiration";i:1586273567;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36";s:5:"login";i:1585063967;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '6'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(20, 1, 'wp_user-settings', 'libraryContent=browse&advImgDetails=show'),
(21, 1, 'wp_user-settings-time', '1584910695'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'hidemy5715_nag_ignore', 'true') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'nousot-dev', '$P$BrOXXzDhCLAHtzQPX84GneryiX5aLK.', 'nousot-dev', 'erica@ericadreisbach.com', '', '2020-02-07 01:32:13', '', 0, 'nousot-dev') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

